<?php
/**
 * Maintenance / coming soon page.
 *
 * A self-contained page: it doesn't load the theme or other plugins' assets, uses system fonts
 * and makes no external requests. Copy it into your theme and point the `hushpage_template` filter at it
 * to customise the markup.
 *
 * Available variables: $hushpage_settings (array), $hushpage_preview (bool).
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hushpage_s        = $hushpage_settings;
$hushpage_logo     = $hushpage_s['logo_id'] ? wp_get_attachment_image_url( (int) $hushpage_s['logo_id'], 'medium' ) : '';
$hushpage_bg       = $hushpage_s['bg_image_id'] ? wp_get_attachment_image_url( (int) $hushpage_s['bg_image_id'], 'full' ) : '';
$hushpage_target   = ( $hushpage_s['show_countdown'] && $hushpage_s['countdown_to'] ) ? Hushpage_Settings::to_timestamp( $hushpage_s['countdown_to'] ) : 0;
$hushpage_title    = $hushpage_s['page_title'] ? $hushpage_s['page_title'] : get_bloginfo( 'name' );
$hushpage_networks = array(
	'facebook.com'  => 'Facebook',
	'instagram.com' => 'Instagram',
	'x.com'         => 'X',
	'twitter.com'   => 'X',
	'linkedin.com'  => 'LinkedIn',
	'youtube.com'   => 'YouTube',
	'tiktok.com'    => 'TikTok',
	'pinterest.com' => 'Pinterest',
);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="hushpage-version" content="<?php echo esc_attr( Hushpage_Settings::page_version( $hushpage_s ) ); ?>">
<title><?php echo esc_html( $hushpage_title ); ?></title>
<?php
$hushpage_icon = get_site_icon_url( 64 );
if ( $hushpage_icon ) {
	printf( '<link rel="icon" href="%s">', esc_url( $hushpage_icon ) );
}
?>
<?php
// Styles go through WordPress's own style API (wp_add_inline_style), never a raw echo.
$hushpage_css = ':root{--hushpage-bg:' . sanitize_hex_color( $hushpage_s['bg_color'] ) . ';--hushpage-text:' . sanitize_hex_color( $hushpage_s['text_color'] ) . ';--hushpage-accent:' . sanitize_hex_color( $hushpage_s['accent_color'] ) . '}'
	. '*{box-sizing:border-box}'
	. 'html,body{margin:0;min-height:100%}'
	. 'body{min-height:100vh;display:flex;align-items:center;justify-content:center;padding:32px 16px;background:var(--hushpage-bg) center/cover no-repeat;color:var(--hushpage-text);font:17px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;text-align:center}'
	. '.hushpage-card{width:100%;max-width:640px}'
	. '.hushpage-has-bg .hushpage-card{background:color-mix(in srgb,var(--hushpage-bg) 88%,transparent);padding:40px 28px;border-radius:16px;backdrop-filter:blur(6px)}'
	. '.hushpage-logo{max-height:96px;max-width:240px;width:auto;height:auto;margin:0 auto 28px;display:block}'
	. 'h1{font-size:clamp(28px,6vw,44px);line-height:1.15;margin:0 0 16px;letter-spacing:-.01em}'
	. '.hushpage-message{margin:0 auto;max-width:56ch}'
	. '.hushpage-message p{margin:0 0 1em}'
	. '.hushpage-message a,.hushpage-contact a,.hushpage-social a{color:var(--hushpage-accent)}'
	. '.hushpage-countdown{display:flex;justify-content:center;gap:12px;margin:28px 0 8px;flex-wrap:wrap}'
	. '.hushpage-countdown div{min-width:72px;padding:12px 8px;border-radius:12px;background:color-mix(in srgb,var(--hushpage-accent) 10%,transparent)}'
	. '.hushpage-countdown b{display:block;font-size:28px;line-height:1.1;color:var(--hushpage-accent);font-variant-numeric:tabular-nums}'
	. '.hushpage-countdown span{font-size:13px;opacity:.75}'
	. '.hushpage-contact{margin-top:24px}'
	. '.hushpage-social{display:flex;justify-content:center;flex-wrap:wrap;gap:8px 18px;margin-top:16px;padding:0;list-style:none}'
	. '.hushpage-footer{margin-top:32px;font-size:14px;opacity:.7}'
	. '.hushpage-preview{position:fixed;top:0;left:0;right:0;background:#1d2327;color:#fff;font-size:13px;padding:6px;z-index:10}'
	. '.hushpage-updates{margin:28px auto 0;max-width:46ch;padding:0;list-style:none;text-align:left}'
	. '.hushpage-updates li{position:relative;padding:0 0 14px 22px;border-left:2px solid color-mix(in srgb,var(--hushpage-accent) 30%,transparent);margin-left:6px}'
	. '.hushpage-updates li:last-child{border-left-color:transparent;padding-bottom:0}'
	. '.hushpage-updates li::before{content:"";position:absolute;left:-6px;top:6px;width:10px;height:10px;border-radius:50%;background:var(--hushpage-accent)}'
	. '.hushpage-updates li:not(:first-child)::before{background:color-mix(in srgb,var(--hushpage-accent) 35%,var(--hushpage-bg))}'
	. '.hushpage-updates time{display:block;font-size:13px;opacity:.7}'
	. '.hushpage-contact-form{margin:32px auto 0;max-width:420px;text-align:left}'
	. '.hushpage-contact-form h2{font-size:20px;margin:0 0 12px;text-align:center}'
	. '.hushpage-contact-form label{display:block;font-size:14px;margin-bottom:4px}'
	. '.hushpage-contact-form input[type=text],.hushpage-contact-form input[type=email],.hushpage-contact-form textarea{width:100%;padding:10px 12px;border:1px solid color-mix(in srgb,var(--hushpage-text) 25%,transparent);border-radius:8px;font:inherit;background:#fff;color:#1d2327}'
	. '.hushpage-contact-form p{margin:0 0 14px}'
	. '.hushpage-consent label{display:flex;gap:8px;align-items:flex-start;font-size:13px;opacity:.85}'
	. '.hushpage-contact-form button{width:100%;padding:12px;border:0;border-radius:8px;background:var(--hushpage-accent);color:#fff;font:inherit;font-weight:600;cursor:pointer}'
	. '.hushpage-hp{position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden}'
	. '.hushpage-form-ok,.hushpage-form-error{padding:10px 12px;border-radius:8px;text-align:center}'
	. '.hushpage-form-ok{background:color-mix(in srgb,#00a32a 12%,transparent)}'
	. '.hushpage-form-error{background:color-mix(in srgb,#d63638 12%,transparent)}'
	. '@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}';
wp_register_style( 'hushpage-page', false, array(), HUSHPAGE_VERSION );
wp_add_inline_style( 'hushpage-page', $hushpage_css );
wp_print_styles( 'hushpage-page' );
?>
</head>
<?php if ( $hushpage_bg ) : ?>
<body class="hushpage-has-bg" style="<?php echo esc_attr( 'background-image:url("' . esc_url( $hushpage_bg ) . '")' ); ?>">
<?php else : ?>
<body>
<?php endif; ?>
<?php if ( $hushpage_preview ) : ?>
	<div class="hushpage-preview" role="status"><?php esc_html_e( 'Preview: this is what visitors see while maintenance mode is on.', 'hushpage' ); ?></div>
<?php endif; ?>
<main class="hushpage-card">
	<?php if ( $hushpage_logo ) : ?>
		<img class="hushpage-logo" src="<?php echo esc_url( $hushpage_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
	<?php endif; ?>
	<?php if ( $hushpage_s['headline'] ) : ?>
		<h1><?php echo esc_html( $hushpage_s['headline'] ); ?></h1>
	<?php endif; ?>
	<?php if ( $hushpage_s['message'] ) : ?>
		<div class="hushpage-message"><?php echo wp_kses_post( wpautop( $hushpage_s['message'] ) ); ?></div>
	<?php endif; ?>

	<?php $hushpage_updates = Hushpage_Settings::updates(); ?>
	<?php if ( $hushpage_updates ) : ?>
		<ol class="hushpage-updates" aria-label="<?php esc_attr_e( 'Progress updates', 'hushpage' ); ?>">
			<?php foreach ( $hushpage_updates as $hushpage_update ) : ?>
				<li><time datetime="<?php echo esc_attr( gmdate( 'c', (int) $hushpage_update['time'] ) ); ?>"><?php echo esc_html( wp_date( get_option( 'time_format' ), (int) $hushpage_update['time'] ) ); ?></time><?php echo esc_html( $hushpage_update['text'] ); ?></li>
			<?php endforeach; ?>
		</ol>
	<?php endif; ?>

	<?php if ( $hushpage_target && $hushpage_target > time() ) : ?>
		<?php $hushpage_left = $hushpage_target - time(); ?>
		<div class="hushpage-countdown" id="hushpage-countdown" data-target="<?php echo esc_attr( (string) $hushpage_target ); ?>" role="timer" aria-live="off">
			<div><b data-unit="d"><?php echo esc_html( (string) floor( $hushpage_left / DAY_IN_SECONDS ) ); ?></b><span><?php esc_html_e( 'days', 'hushpage' ); ?></span></div>
			<div><b data-unit="h"><?php echo esc_html( (string) floor( ( $hushpage_left % DAY_IN_SECONDS ) / HOUR_IN_SECONDS ) ); ?></b><span><?php esc_html_e( 'hours', 'hushpage' ); ?></span></div>
			<div><b data-unit="m"><?php echo esc_html( (string) floor( ( $hushpage_left % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS ) ); ?></b><span><?php esc_html_e( 'minutes', 'hushpage' ); ?></span></div>
			<div><b data-unit="s"><?php echo esc_html( (string) ( $hushpage_left % MINUTE_IN_SECONDS ) ); ?></b><span><?php esc_html_e( 'seconds', 'hushpage' ); ?></span></div>
		</div>
		<?php
		wp_print_inline_script_tag(
			'(function(){var el=document.getElementById("hushpage-countdown");if(!el)return;var t=parseInt(el.getAttribute("data-target"),10)*1000;'
			. 'function tick(){var s=Math.max(0,Math.floor((t-Date.now())/1000));var v={d:Math.floor(s/86400),h:Math.floor(s%86400/3600),m:Math.floor(s%3600/60),s:s%60};'
			. 'el.querySelectorAll("[data-unit]").forEach(function(b){b.textContent=v[b.getAttribute("data-unit")];});if(s>0)setTimeout(tick,1000);}tick();})();'
		);
		?>
	<?php endif; ?>

	<?php
	if ( ! empty( $hushpage_s['contact_form'] ) ) {
		Hushpage_Contact::render_form( $hushpage_s );
	}
	?>

	<?php if ( $hushpage_s['contact_email'] ) : ?>
		<p class="hushpage-contact">
			<?php
			printf(
				/* translators: %s: contact email address link */
				esc_html__( 'Need to reach us? Email %s', 'hushpage' ),
				'<a href="' . esc_url( 'mailto:' . antispambot( $hushpage_s['contact_email'] ) ) . '">' . esc_html( antispambot( $hushpage_s['contact_email'] ) ) . '</a>'
			);
			?>
		</p>
	<?php endif; ?>

	<?php if ( ! empty( $hushpage_s['social_links'] ) ) : ?>
		<ul class="hushpage-social">
			<?php
			foreach ( $hushpage_s['social_links'] as $hushpage_link ) :
				$hushpage_host  = preg_replace( '/^www\./', '', (string) wp_parse_url( $hushpage_link, PHP_URL_HOST ) );
				$hushpage_label = isset( $hushpage_networks[ $hushpage_host ] ) ? $hushpage_networks[ $hushpage_host ] : $hushpage_host;
				?>
				<li><a href="<?php echo esc_url( $hushpage_link ); ?>" rel="noopener noreferrer"><?php echo esc_html( $hushpage_label ); ?></a></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<?php if ( $hushpage_s['footer_text'] ) : ?>
		<p class="hushpage-footer"><?php echo esc_html( $hushpage_s['footer_text'] ); ?></p>
	<?php endif; ?>
</main>
<?php
if ( ! empty( $hushpage_s['live_refresh'] ) && ! $hushpage_preview ) {
	// Once a minute (only while the tab is visible) re-check this same address: reload when the status updates
	// change, or when the real site answers again because maintenance has ended. No external requests.
	wp_print_inline_script_tag(
		'(function(){var m=document.querySelector(\'meta[name="hushpage-version"]\');if(!m||!window.fetch)return;var cur=m.getAttribute("content");'
		. 'function busy(){var f=document.querySelector(".hushpage-contact-form form");if(!f)return false;'
		. 'if(f.contains(document.activeElement))return true;return [].some.call(f.querySelectorAll("input[type=text],input[type=email],textarea"),function(e){return e.value!=="";});}'
		. 'function check(){if(document.hidden||busy())return;fetch(location.href,{cache:"no-store",credentials:"same-origin"}).then(function(r){'
		. 'return r.text().then(function(t){var v=t.match(/name="hushpage-version" content="([a-f0-9]+)"/);'
		. 'if((v&&v[1]!==cur)||(!v&&r.ok)){location.reload();}});}).catch(function(){});}'
		. 'setInterval(check,60000);})();'
	);
}
?>
</body>
</html>
