<?php
/**
 * Plugin Name:       UBAS Maintenance Mode
 * Description:       Hushpage (nag-free maintenance and coming soon page) with a password in front of its settings. Same settings and messages as Hushpage, so it replaces it.
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            UBAS (based on Hushpage by Cornerstone AI Works)
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       hushpage
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Replaces the original Hushpage plugin. If that plugin is still active, do nothing but say so,
 * so the two never load together (they share class and function names).
 */
if ( defined( 'HUSHPAGE_VERSION' ) || class_exists( 'Hushpage_Settings', false ) ) {
	add_action(
		'admin_notices',
		static function () {
			echo '<div class="notice notice-error"><p><strong>UBAS Maintenance Mode</strong> is not running because the original Hushpage plugin is still active. Deactivate Hushpage (do not delete it), then reload this page.</p></div>';
		}
	);
	return;
}

define( 'HUSHPAGE_VERSION', '1.2.0' );
define( 'HUSHPAGE_FILE', __FILE__ );
define( 'HUSHPAGE_DIR', plugin_dir_path( __FILE__ ) );
define( 'HUSHPAGE_URL', plugin_dir_url( __FILE__ ) );
define( 'HUSHPAGE_OPTION', 'hushpage_settings' );

require_once HUSHPAGE_DIR . 'includes/class-hushpage-settings.php';
require_once HUSHPAGE_DIR . 'includes/class-hushpage-gate.php';
require_once HUSHPAGE_DIR . 'includes/class-hushpage-admin.php';
require_once HUSHPAGE_DIR . 'includes/class-hushpage-health.php';
require_once HUSHPAGE_DIR . 'includes/class-hushpage-contact.php';
require_once HUSHPAGE_DIR . 'includes/class-hushpage-lock.php';

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once HUSHPAGE_DIR . 'includes/class-hushpage-cli.php';
	WP_CLI::add_command( 'hushpage', 'Hushpage_CLI' );
}

Hushpage_Gate::init();
Hushpage_Health::init();
Hushpage_Contact::init();
Hushpage_Lock::init();
if ( is_admin() ) {
	Hushpage_Admin::init();
}
add_action( 'admin_bar_menu', array( 'Hushpage_Admin', 'admin_bar' ), 100 );
add_action( 'wp_enqueue_scripts', array( 'Hushpage_Admin', 'admin_bar_style' ) );
add_action( 'admin_enqueue_scripts', array( 'Hushpage_Admin', 'admin_bar_style' ) );

/**
 * On activation: store defaults (maintenance stays OFF until the owner turns it on).
 */
function hushpage_activate() {
	if ( false === get_option( HUSHPAGE_OPTION ) ) {
		add_option( HUSHPAGE_OPTION, Hushpage_Settings::defaults(), '', false );
	}
}
register_activation_hook( __FILE__, 'hushpage_activate' );

/**
 * On deactivation: visitors must never stay locked out, so clear caches that may hold the maintenance page.
 */
function hushpage_deactivate() {
	wp_clear_scheduled_hook( Hushpage_Settings::CRON_HOOK );
	wp_clear_scheduled_hook( Hushpage_Contact::CLEANUP_HOOK );
	Hushpage_Settings::purge_caches( 'deactivated' );
}
register_deactivation_hook( __FILE__, 'hushpage_deactivate' );
