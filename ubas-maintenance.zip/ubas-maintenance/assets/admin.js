/* Hushpage: settings screen. Uses WordPress's bundled colour picker and media library. */
( function ( $ ) {
	'use strict';
	$( function () {
		$( '.hushpage-color' ).wpColorPicker();

		$( '.hushpage-image' ).each( function () {
			var $box = $( this ), frame;
			var $input = $box.find( 'input[type=hidden]' ), $img = $box.find( 'img' ), $remove = $box.find( '.hushpage-image-remove' );
			$box.find( '.hushpage-image-choose' ).on( 'click', function () {
				if ( ! frame ) {
					frame = wp.media( { title: hushpageAdmin.chooseImage, button: { text: hushpageAdmin.useImage }, library: { type: 'image' }, multiple: false } );
					frame.on( 'select', function () {
						var a = frame.state().get( 'selection' ).first().toJSON();
						var url = ( a.sizes && a.sizes.thumbnail ) ? a.sizes.thumbnail.url : a.url;
						$input.val( a.id );
						$img.attr( 'src', url ).prop( 'hidden', false );
						$remove.prop( 'hidden', false );
					} );
				}
				frame.open();
			} );
			$remove.on( 'click', function () {
				$input.val( '0' );
				$img.attr( 'src', '' ).prop( 'hidden', true );
				$remove.prop( 'hidden', true );
			} );
		} );

		$( '.hushpage-copy' ).on( 'click', function () {
			var $btn = $( this ), field = document.getElementById( $btn.data( 'target' ) ), label = $btn.text();
			var done = function () { $btn.text( hushpageAdmin.copied ); setTimeout( function () { $btn.text( label ); }, 1500 ); };
			if ( navigator.clipboard && window.isSecureContext ) {
				navigator.clipboard.writeText( field.value ).then( done );
			} else {
				field.select();
				document.execCommand( 'copy' );
				done();
			}
		} );

		$( '.hushpage-switch input' ).on( 'change', function () {
			$( '.hushpage-status' ).toggleClass( 'is-on', this.checked );
		} );
	} );
}( jQuery ) );
