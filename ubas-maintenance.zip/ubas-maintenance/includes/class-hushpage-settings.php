<?php
/**
 * Settings storage, sanitising and helpers.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * All settings live in a single, non-autoloaded option (HUSHPAGE_OPTION).
 */
class Hushpage_Settings {

	const LOG_OPTION   = 'hushpage_cache_log';
	const STATE_OPTION = 'hushpage_state';
	const CRON_HOOK    = 'hushpage_window_tick';
	const LOG_SIZE     = 20;

	const UPDATES_OPTION = 'hushpage_updates';
	const UPDATES_SIZE   = 10;
	const UPDATE_LENGTH  = 280;

	/**
	 * True while Hushpage itself saves the settings (scheduled switch), so the save hook doesn't purge twice.
	 *
	 * @var bool
	 */
	public static $internal_save = false;

	/**
	 * Default settings. Maintenance mode is off until the owner switches it on.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'enabled'         => false,
			'mode'            => 'maintenance',
			'start_at'        => '',
			'end_at'          => '',
			'enabled_since'   => 0,
			'scope'           => 'site',
			'paths'           => '',
			'exclude_paths'   => '',
			'notify_email'    => true,
			'live_refresh'    => true,
			'contact_form'    => false,
			'contact_heading' => __( 'Leave us a message', 'hushpage' ),
			'contact_notify'  => true,
			'contact_retention' => 90,
			'page_title'      => __( 'Down for maintenance', 'hushpage' ),
			'headline'        => __( 'We\'ll be back soon', 'hushpage' ),
			'message'         => __( 'We\'re making some improvements to the site. Thanks for your patience, and please check back shortly.', 'hushpage' ),
			'footer_text'     => '',
			'contact_email'   => '',
			'social_links'    => array(),
			'show_countdown'  => false,
			'countdown_to'    => '',
			'logo_id'         => 0,
			'bg_image_id'     => 0,
			'bg_color'        => '#f4f5f7',
			'text_color'      => '#1d2327',
			'accent_color'    => '#2271b1',
			'bypass_roles'    => array( 'administrator' ),
			'ip_allowlist'    => '',
			'bypass_token'    => self::new_token(),
			'bypass_days'     => 7,
			'allow_rest'      => true,
			'retry_after'     => 2,
			'noindex'         => true,
		);
	}

	/**
	 * Current settings merged over defaults.
	 *
	 * @return array
	 */
	public static function get() {
		$saved = get_option( HUSHPAGE_OPTION, array() );
		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * Random token for the secret bypass link.
	 *
	 * @return string
	 */
	public static function new_token() {
		return wp_generate_password( 24, false, false );
	}

	/**
	 * Is the maintenance page active right now? Applies the maintenance window (scheduled start and
	 * switch-off) and the HUSHPAGE_DISABLE emergency constant (define( 'HUSHPAGE_DISABLE', true ); in wp-config.php).
	 *
	 * @return bool
	 */
	public static function is_active() {
		if ( defined( 'HUSHPAGE_DISABLE' ) && HUSHPAGE_DISABLE ) {
			return false;
		}
		$s = self::get();
		if ( empty( $s['enabled'] ) ) {
			return false;
		}
		$now   = time();
		$end   = self::to_timestamp( $s['end_at'] );
		$start = self::to_timestamp( $s['start_at'] );
		if ( $end && $now >= $end ) {
			$s['enabled']       = false;
			$s['start_at']      = '';
			$s['end_at']        = '';
			$s['enabled_since'] = 0;
			self::save_internal( $s );
			self::clear_updates();
			self::purge_caches( 'scheduled_end' );
			self::notify( $s, 'ended' );
			return false;
		}
		if ( $start && $now < $start ) {
			return false; // switched on, but the window hasn't opened yet.
		}
		if ( $start ) {
			$state = get_option( self::STATE_OPTION, array() );
			if ( ! is_array( $state ) || ( isset( $state['started_for'] ) ? $state['started_for'] : '' ) !== $s['start_at'] ) {
				update_option( self::STATE_OPTION, array( 'started_for' => $s['start_at'] ), false );
				$s['enabled_since'] = $start;
				self::save_internal( $s );
				self::purge_caches( 'scheduled_start' );
				self::notify( $s, 'started' );
			}
		}
		return true;
	}

	/**
	 * Saves settings without triggering the "settings changed" cache purge (the caller purges with its own reason).
	 *
	 * @param array $s Settings.
	 */
	public static function save_internal( $s ) {
		self::$internal_save = true;
		update_option( HUSHPAGE_OPTION, $s, false );
		self::$internal_save = false;
	}

	/**
	 * Is the switch on with a start time still in the future?
	 *
	 * @return int Start timestamp, or 0 when nothing is scheduled.
	 */
	public static function scheduled_start() {
		$s     = self::get();
		$start = self::to_timestamp( $s['start_at'] );
		return ( ! empty( $s['enabled'] ) && $start > time() ) ? $start : 0;
	}

	/**
	 * Schedules WP-Cron events at the window's start and end, so the switch happens on time even when a
	 * page cache serves visitors without running PHP. Called after every save.
	 *
	 * @param array $s Settings.
	 */
	public static function schedule_window( $s ) {
		wp_clear_scheduled_hook( self::CRON_HOOK );
		if ( empty( $s['enabled'] ) ) {
			return;
		}
		foreach ( array( $s['start_at'], $s['end_at'] ) as $when ) {
			$ts = self::to_timestamp( $when );
			if ( $ts > time() ) {
				wp_schedule_single_event( $ts + 5, self::CRON_HOOK );
			}
		}
	}

	/**
	 * Emails the site administrator when a scheduled window starts or ends (if enabled in settings).
	 *
	 * @param array  $s     Settings.
	 * @param string $event started|ended.
	 */
	private static function notify( $s, $event ) {
		if ( empty( $s['notify_email'] ) ) {
			return;
		}
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		if ( 'started' === $event ) {
			/* translators: %s: site name */
			$subject = sprintf( __( '[%s] Maintenance page is now on', 'hushpage' ), $site );
			$body    = __( 'Your scheduled maintenance window has started. Visitors now see the maintenance page; you and the roles you allowed still see the site.', 'hushpage' );
		} else {
			/* translators: %s: site name */
			$subject = sprintf( __( '[%s] Maintenance page is now off', 'hushpage' ), $site );
			$body    = __( 'Your scheduled maintenance window has ended and the site is visible to everyone again. Page caches were cleared.', 'hushpage' );
		}
		$body .= "\n\n" . admin_url( 'options-general.php?page=hushpage' );
		wp_mail( get_option( 'admin_email' ), $subject, $body );
	}

	/**
	 * Converts a site-local "Y-m-d\TH:i" value to a UTC timestamp (0 when empty or invalid).
	 *
	 * @param string $value Local date and time.
	 * @return int
	 */
	public static function to_timestamp( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return 0;
		}
		$date = date_create_immutable_from_format( 'Y-m-d\TH:i', $value, wp_timezone() );
		return $date ? $date->getTimestamp() : 0;
	}

	/**
	 * Sanitises the settings form (Settings API callback).
	 *
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public static function sanitize( $input ) {
		$old = self::get();
		$in  = is_array( $input ) ? $input : array();
		$out = $old;

		$out['enabled']        = ! empty( $in['enabled'] );
		$out['mode']           = ( isset( $in['mode'] ) && 'coming_soon' === $in['mode'] ) ? 'coming_soon' : 'maintenance';
		$out['start_at']       = self::sanitize_datetime( isset( $in['start_at'] ) ? $in['start_at'] : '' );
		$out['end_at']         = self::sanitize_datetime( isset( $in['end_at'] ) ? $in['end_at'] : '' );
		if ( $out['start_at'] && $out['end_at'] && self::to_timestamp( $out['end_at'] ) <= self::to_timestamp( $out['start_at'] ) ) {
			$out['end_at'] = '';
			add_settings_error( HUSHPAGE_OPTION, 'hushpage_window', __( 'The switch-off time must be after the start time, so it was cleared.', 'hushpage' ) );
		}
		if ( ! $out['enabled'] ) {
			$out['enabled_since'] = 0;
		} elseif ( empty( $old['enabled'] ) || empty( $old['enabled_since'] ) ) {
			$start                = self::to_timestamp( $out['start_at'] );
			$out['enabled_since'] = $start > time() ? $start : time();
		}
		$out['scope']          = ( isset( $in['scope'] ) && 'paths' === $in['scope'] ) ? 'paths' : 'site';
		$out['paths']          = self::sanitize_paths( isset( $in['paths'] ) ? $in['paths'] : '' );
		$out['exclude_paths']  = self::sanitize_paths( isset( $in['exclude_paths'] ) ? $in['exclude_paths'] : '' );
		if ( 'paths' === $out['scope'] && '' === $out['paths'] ) {
			add_settings_error( HUSHPAGE_OPTION, 'hushpage_paths', __( 'You chose "Only these pages" but listed none, so no page shows the maintenance page.', 'hushpage' ), 'warning' );
		}
		$out['notify_email']   = ! empty( $in['notify_email'] );
		$out['live_refresh']   = ! empty( $in['live_refresh'] );
		$out['contact_form']   = ! empty( $in['contact_form'] );
		$heading               = sanitize_text_field( isset( $in['contact_heading'] ) ? $in['contact_heading'] : '' );
		$out['contact_heading'] = '' !== $heading ? $heading : __( 'Leave us a message', 'hushpage' );
		$out['contact_notify']  = ! empty( $in['contact_notify'] );
		$out['contact_retention'] = min( 365, max( 1, absint( isset( $in['contact_retention'] ) ? $in['contact_retention'] : 90 ) ) );
		$out['page_title']     = sanitize_text_field( isset( $in['page_title'] ) ? $in['page_title'] : '' );
		$out['headline']       = sanitize_text_field( isset( $in['headline'] ) ? $in['headline'] : '' );
		$out['message']        = wp_kses_post( isset( $in['message'] ) ? $in['message'] : '' );
		$out['footer_text']    = sanitize_text_field( isset( $in['footer_text'] ) ? $in['footer_text'] : '' );
		$out['contact_email']  = sanitize_email( isset( $in['contact_email'] ) ? $in['contact_email'] : '' );
		$out['show_countdown'] = ! empty( $in['show_countdown'] );
		$out['countdown_to']   = self::sanitize_datetime( isset( $in['countdown_to'] ) ? $in['countdown_to'] : '' );
		$out['logo_id']        = absint( isset( $in['logo_id'] ) ? $in['logo_id'] : 0 );
		$out['bg_image_id']    = absint( isset( $in['bg_image_id'] ) ? $in['bg_image_id'] : 0 );
		foreach ( array( 'bg_color', 'text_color', 'accent_color' ) as $key ) {
			$color       = sanitize_hex_color( isset( $in[ $key ] ) ? $in[ $key ] : '' );
			$out[ $key ] = $color ? $color : $old[ $key ];
		}
		$out['allow_rest']  = ! empty( $in['allow_rest'] );
		$out['noindex']     = ! empty( $in['noindex'] );
		$out['retry_after'] = min( 168, max( 1, absint( isset( $in['retry_after'] ) ? $in['retry_after'] : 2 ) ) );
		$out['bypass_days'] = min( 90, max( 1, absint( isset( $in['bypass_days'] ) ? $in['bypass_days'] : 7 ) ) );

		$links = array();
		if ( isset( $in['social_links'] ) && is_array( $in['social_links'] ) ) {
			foreach ( array_slice( $in['social_links'], 0, 6 ) as $link ) {
				$url = esc_url_raw( trim( (string) $link ), array( 'http', 'https' ) );
				if ( $url ) {
					$links[] = $url;
				}
			}
		}
		$out['social_links'] = $links;

		$roles = array( 'administrator' );
		if ( isset( $in['bypass_roles'] ) && is_array( $in['bypass_roles'] ) ) {
			$editable = array_keys( wp_roles()->roles );
			foreach ( $in['bypass_roles'] as $role ) {
				$role = sanitize_key( $role );
				if ( in_array( $role, $editable, true ) ) {
					$roles[] = $role;
				}
			}
		}
		$out['bypass_roles'] = array_values( array_unique( $roles ) );

		$ips = array();
		$raw = isset( $in['ip_allowlist'] ) ? (string) $in['ip_allowlist'] : '';
		foreach ( preg_split( '/[\s,]+/', $raw ) as $ip ) {
			$ip = trim( $ip );
			if ( '' !== $ip && filter_var( $ip, FILTER_VALIDATE_IP ) ) {
				$ips[] = $ip;
			}
		}
		$out['ip_allowlist'] = implode( "\n", array_unique( $ips ) );

		if ( isset( $in['bypass_token'] ) && is_string( $in['bypass_token'] ) && preg_match( '/^[A-Za-z0-9]{24}$/', $in['bypass_token'] ) ) {
			$out['bypass_token'] = $in['bypass_token'];
		}
		if ( empty( $out['bypass_token'] ) ) {
			$out['bypass_token'] = self::new_token();
		}
		return $out;
	}

	/**
	 * One site path per line, e.g. "/shop/". Full URLs are reduced to their path. At most 50 entries.
	 *
	 * @param mixed $raw Raw textarea value.
	 * @return string Newline-separated paths.
	 */
	public static function sanitize_paths( $raw ) {
		$paths = array();
		foreach ( preg_split( '/[\r\n]+/', (string) $raw ) as $line ) {
			$line = trim( sanitize_text_field( $line ) );
			if ( '' === $line ) {
				continue;
			}
			$path = (string) wp_parse_url( $line, PHP_URL_PATH );
			$path = '/' . ltrim( preg_replace( '#[^A-Za-z0-9/_.~%-]#', '', $path ), '/' );
			if ( '/' !== $path || '/' === $line ) {
				$paths[] = substr( $path, 0, 200 );
			}
		}
		return implode( "\n", array_slice( array_values( array_unique( $paths ) ), 0, 50 ) );
	}

	/**
	 * Does a request path fall under one of the listed paths? "/shop" covers "/shop", "/shop/" and "/shop/cart/".
	 *
	 * @param string $path Request path, relative to the site's home path.
	 * @param string $list Newline-separated paths.
	 * @return bool
	 */
	public static function path_matches( $path, $list ) {
		$path = '/' . ltrim( $path, '/' );
		foreach ( array_filter( explode( "\n", (string) $list ) ) as $entry ) {
			$entry = rtrim( $entry, '/' );
			if ( '' === $entry ) {
				if ( '/' === $path ) {
					return true; // "/" means the home page only.
				}
				continue;
			}
			if ( $path === $entry || 0 === strpos( $path, $entry . '/' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Accepts only "Y-m-d\TH:i" (the datetime-local input format).
	 *
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private static function sanitize_datetime( $value ) {
		$value = sanitize_text_field( (string) $value );
		return ( '' !== $value && self::to_timestamp( $value ) ) ? $value : '';
	}

	/**
	 * Clears page caches from common caching plugins and hosts, so visitors never get a stale
	 * maintenance page (or a stale live page) after switching. Only calls what is installed, and
	 * records what was cleared in a short log shown on the settings screen.
	 *
	 * @param string $reason Why: settings_saved, scheduled_start, scheduled_end, wp_cli, deactivated.
	 * @return string[] Names of the caches that were cleared.
	 */
	public static function purge_caches( $reason = 'settings_saved' ) {
		$cleared = array();
		wp_cache_flush();
		if ( wp_using_ext_object_cache() ) {
			$cleared[] = 'Object cache';
		}
		// These are the documented purge hooks of other caching plugins (they only run if that plugin is installed),
		// so they can't carry this plugin's prefix.
		$hooks = array(
			'litespeed_purge_all'    => 'LiteSpeed Cache',
			'wpo_cache_flush'        => 'WP-Optimize',
			'wpfc_clear_all_cache'   => 'WP Fastest Cache',
			'breeze_clear_all_cache' => 'Breeze',
		);
		foreach ( $hooks as $hook => $name ) {
			if ( has_action( $hook ) ) {
				$cleared[] = $name;
			}
		}
		do_action( 'litespeed_purge_all' );     // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- LiteSpeed Cache's hook.
		do_action( 'wpo_cache_flush' );         // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP-Optimize's hook.
		do_action( 'wpfc_clear_all_cache' );    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WP Fastest Cache's hook.
		do_action( 'breeze_clear_all_cache' );  // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Breeze's hook.
		$functions = array(
			'wp_cache_clear_cache'      => 'WP Super Cache',
			'rocket_clean_domain'       => 'WP Rocket',
			'w3tc_flush_all'            => 'W3 Total Cache',
			'sg_cachepress_purge_cache' => 'SiteGround Speed Optimizer',
		);
		foreach ( $functions as $fn => $name ) {
			if ( function_exists( $fn ) ) {
				call_user_func( $fn );
				$cleared[] = $name;
			}
		}
		if ( has_action( 'hushpage_purge_caches' ) ) {
			$cleared[] = __( 'Custom (hushpage_purge_caches)', 'hushpage' );
		}
		/**
		 * Fires after Hushpage clears caches, for hosts and plugins not covered above.
		 */
		do_action( 'hushpage_purge_caches' );

		$log = get_option( self::LOG_OPTION, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift(
			$log,
			array(
				'time'    => time(),
				'reason'  => sanitize_key( $reason ),
				'cleared' => $cleared,
			)
		);
		update_option( self::LOG_OPTION, array_slice( $log, 0, self::LOG_SIZE ), false );
		return $cleared;
	}

	/**
	 * Live status updates shown on the maintenance page, newest first.
	 *
	 * @return array[] Each: time (int), text (string).
	 */
	public static function updates() {
		$updates = get_option( self::UPDATES_OPTION, array() );
		return is_array( $updates ) ? $updates : array();
	}

	/**
	 * Posts a short plain-text status update ("Backups done", "Almost there").
	 *
	 * @param string $text Update text.
	 * @return bool False when the text is empty after sanitising.
	 */
	public static function add_update( $text ) {
		$text = trim( sanitize_text_field( (string) $text ) );
		if ( '' === $text ) {
			return false;
		}
		$text    = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, self::UPDATE_LENGTH ) : substr( $text, 0, self::UPDATE_LENGTH );
		$updates = self::updates();
		array_unshift(
			$updates,
			array(
				'time' => time(),
				'text' => $text,
			)
		);
		update_option( self::UPDATES_OPTION, array_slice( $updates, 0, self::UPDATES_SIZE ), false );
		return true;
	}

	/**
	 * Removes all status updates (done automatically when the maintenance page switches off).
	 */
	public static function clear_updates() {
		delete_option( self::UPDATES_OPTION );
	}

	/**
	 * Short fingerprint of what visitors see; open pages reload when it changes.
	 *
	 * @param array $s Settings.
	 * @return string
	 */
	public static function page_version( $s ) {
		return substr( md5( wp_json_encode( array( self::updates(), $s['mode'], $s['headline'], $s['message'] ) ) ), 0, 12 );
	}

	/**
	 * Recent cache clearing, newest first.
	 *
	 * @return array[]
	 */
	public static function cache_log() {
		$log = get_option( self::LOG_OPTION, array() );
		return is_array( $log ) ? $log : array();
	}

	/**
	 * Is a page cache active that Hushpage has no way to clear? (WP_CACHE on with none of the known plugins present.)
	 *
	 * @return bool
	 */
	public static function has_unknown_page_cache() {
		if ( ! defined( 'WP_CACHE' ) || ! WP_CACHE || ! file_exists( WP_CONTENT_DIR . '/advanced-cache.php' ) ) {
			return false;
		}
		foreach ( array( 'litespeed_purge_all', 'wpo_cache_flush', 'wpfc_clear_all_cache', 'breeze_clear_all_cache', 'hushpage_purge_caches' ) as $hook ) {
			if ( has_action( $hook ) ) {
				return false;
			}
		}
		foreach ( array( 'wp_cache_clear_cache', 'rocket_clean_domain', 'w3tc_flush_all', 'sg_cachepress_purge_cache' ) as $fn ) {
			if ( function_exists( $fn ) ) {
				return false;
			}
		}
		return true;
	}
}
