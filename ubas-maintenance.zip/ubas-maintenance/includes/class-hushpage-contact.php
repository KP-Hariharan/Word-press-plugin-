<?php
/**
 * "Leave us a message" form on the maintenance page: storage, spam protection, admin inbox,
 * CSV export, email alerts, retention and WordPress's personal-data export/erase tools.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Contact form and message inbox.
 */
class Hushpage_Contact {

	const POST_TYPE    = 'hushpage_message';
	const CLEANUP_HOOK = 'hushpage_cleanup';
	const MIN_SECONDS  = 3;       // Humans take longer than this to fill the form; bots usually don't.
	const MAX_AGE      = DAY_IN_SECONDS;
	const RATE_LIMIT   = 3;       // Messages per visitor per window.
	const RATE_WINDOW  = 10 * MINUTE_IN_SECONDS;
	const PER_PAGE     = 20;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'admin_post_nopriv_hushpage_contact', array( __CLASS__, 'handle_submit' ) );
		add_action( 'admin_post_hushpage_contact', array( __CLASS__, 'handle_submit' ) );
		add_action( 'admin_post_hushpage_message_action', array( __CLASS__, 'handle_admin_action' ) );
		add_action( 'admin_post_hushpage_export_messages', array( __CLASS__, 'export_csv' ) );
		add_action( self::CLEANUP_HOOK, array( __CLASS__, 'cleanup' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );
		add_action( 'admin_init', array( __CLASS__, 'privacy_policy_content' ) );
	}

	/**
	 * Messages are private posts: never public, never in search, no admin UI of their own.
	 */
	public static function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array( 'name' => __( 'Maintenance messages', 'hushpage' ) ),
				'public'              => false,
				'show_ui'             => false,
				'show_in_rest'        => false,
				'exclude_from_search' => true,
				'publicly_queryable'  => false,
				'query_var'           => false,
				'rewrite'             => false,
				'supports'            => array( 'title', 'editor' ),
				'capability_type'     => 'post',
				'capabilities'        => array( 'create_posts' => 'do_not_allow' ),
				'map_meta_cap'        => true,
			)
		);
	}

	/**
	 * Daily retention clean-up is scheduled while the form is on (or messages exist).
	 */
	public static function schedule_cleanup() {
		if ( ! wp_next_scheduled( self::CLEANUP_HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CLEANUP_HOOK );
		}
	}

	// ------------------------------------------------------------------ the form on the maintenance page

	/**
	 * Signed timestamp for the time trap (proves when the form was rendered, can't be forged).
	 *
	 * @param int $time Timestamp.
	 * @return string
	 */
	private static function time_token( $time ) {
		return $time . '.' . substr( wp_hash( 'hushpage_form|' . $time, 'nonce' ), 0, 20 );
	}

	/**
	 * Renders the form (called by the page template).
	 *
	 * @param array $s Settings.
	 */
	public static function render_form( $s ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only result flag set by our own redirect.
		$result  = isset( $_GET['hushpage_sent'] ) ? sanitize_key( wp_unslash( $_GET['hushpage_sent'] ) ) : '';
		$notices = array(
			'ok'      => __( 'Thank you. Your message was sent, and we\'ll reply as soon as we can.', 'hushpage' ),
			'invalid' => __( 'Please fill in your name, a valid email address and a message, and tick the consent box.', 'hushpage' ),
			'expired' => __( 'The form expired. Please send your message again.', 'hushpage' ),
			'limit'   => __( 'You\'ve sent several messages already. Please try again in a few minutes.', 'hushpage' ),
		);
		$privacy = get_privacy_policy_url();
		?>
		<section class="hushpage-contact-form" aria-labelledby="hushpage-contact-title">
			<h2 id="hushpage-contact-title"><?php echo esc_html( $s['contact_heading'] ); ?></h2>
			<?php if ( isset( $notices[ $result ] ) ) : ?>
				<p class="<?php echo esc_attr( 'ok' === $result ? 'hushpage-form-ok' : 'hushpage-form-error' ); ?>" role="status"><?php echo esc_html( $notices[ $result ] ); ?></p>
			<?php endif; ?>
			<?php if ( 'ok' !== $result ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="hushpage_contact">
					<input type="hidden" name="hushpage_return" value="<?php echo esc_attr( Hushpage_Gate::request_path() ); ?>">
					<input type="hidden" name="hushpage_t" value="<?php echo esc_attr( self::time_token( time() ) ); ?>">
					<?php wp_nonce_field( 'hushpage_contact', 'hushpage_nonce' ); ?>
					<div class="hushpage-hp" aria-hidden="true">
						<label for="hushpage-website"><?php esc_html_e( 'Leave this field empty', 'hushpage' ); ?></label>
						<input type="text" id="hushpage-website" name="hushpage_website" tabindex="-1" autocomplete="off">
					</div>
					<p><label for="hushpage-name"><?php esc_html_e( 'Name', 'hushpage' ); ?></label>
						<input type="text" id="hushpage-name" name="hushpage_name" maxlength="100" autocomplete="name" required></p>
					<p><label for="hushpage-email"><?php esc_html_e( 'Email', 'hushpage' ); ?></label>
						<input type="email" id="hushpage-email" name="hushpage_email" maxlength="190" autocomplete="email" required></p>
					<p><label for="hushpage-message"><?php esc_html_e( 'Message', 'hushpage' ); ?></label>
						<textarea id="hushpage-message" name="hushpage_message" rows="4" minlength="10" maxlength="3000" required></textarea></p>
					<p class="hushpage-consent"><label><input type="checkbox" name="hushpage_consent" value="1" required>
						<?php
						if ( $privacy ) {
							printf(
								/* translators: %s: link to the privacy policy */
								esc_html__( 'I agree that my name, email and message are stored so you can reply (see the %s).', 'hushpage' ),
								'<a href="' . esc_url( $privacy ) . '">' . esc_html__( 'privacy policy', 'hushpage' ) . '</a>'
							);
						} else {
							esc_html_e( 'I agree that my name, email and message are stored so you can reply.', 'hushpage' );
						}
						?>
					</label></p>
					<p><button type="submit"><?php esc_html_e( 'Send message', 'hushpage' ); ?></button></p>
				</form>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Where to send the visitor back to (always a path on this site).
	 *
	 * @param string $result Result flag for the page.
	 */
	private static function back( $result ) {
		$path = isset( $_POST['hushpage_return'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_return'] ) ) : '/'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- only used to build a same-site redirect.
		$path = '/' . ltrim( (string) wp_parse_url( $path, PHP_URL_PATH ), '/' );
		$url  = wp_validate_redirect( home_url( $path ), home_url( '/' ) );
		wp_safe_redirect( add_query_arg( 'hushpage_sent', $result, $url ) . '#hushpage-contact-title' );
		exit;
	}

	/**
	 * Admin-post (logged in or not): validates, filters spam and stores one message.
	 */
	public static function handle_submit() {
		$s = Hushpage_Settings::get();
		if ( empty( $s['contact_form'] ) ) {
			self::back( 'invalid' );
		}
		$nonce = isset( $_POST['hushpage_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'hushpage_contact' ) ) {
			self::back( 'expired' );
		}
		// Honeypot and time trap: bots get the normal "thank you" so they learn nothing, but nothing is stored.
		$trap  = isset( $_POST['hushpage_website'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_website'] ) ) : '';
		$token = isset( $_POST['hushpage_t'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_t'] ) ) : '';
		$parts = explode( '.', $token, 2 );
		$valid = 2 === count( $parts ) && ctype_digit( $parts[0] ) && hash_equals( self::time_token( (int) $parts[0] ), $token );
		$age   = $valid ? time() - (int) $parts[0] : -1;
		if ( '' !== $trap || $age < self::MIN_SECONDS ) {
			self::back( 'ok' );
		}
		if ( $age > self::MAX_AGE ) {
			self::back( 'expired' );
		}

		$name    = isset( $_POST['hushpage_name'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_name'] ) ) : '';
		$email   = isset( $_POST['hushpage_email'] ) ? sanitize_email( wp_unslash( $_POST['hushpage_email'] ) ) : '';
		$message = isset( $_POST['hushpage_message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['hushpage_message'] ) ) : '';
		$consent = ! empty( $_POST['hushpage_consent'] );
		$name    = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 100 ) : substr( $name, 0, 100 );
		$message = function_exists( 'mb_substr' ) ? mb_substr( $message, 0, 3000 ) : substr( $message, 0, 3000 );
		if ( '' === $name || ! is_email( $email ) || strlen( trim( $message ) ) < 10 || ! $consent ) {
			self::back( 'invalid' );
		}

		// Rate limit per visitor; the key is a hash, the IP address itself is never stored.
		$key   = 'hushpage_rl_' . substr( wp_hash( Hushpage_Gate::client_ip() . '|contact' ), 0, 20 );
		$count = (int) get_transient( $key );
		if ( $count >= self::RATE_LIMIT ) {
			self::back( 'limit' );
		}
		set_transient( $key, $count + 1, self::RATE_WINDOW );

		$path = isset( $_POST['hushpage_return'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_return'] ) ) : '/';
		$id   = wp_insert_post(
			array(
				'post_type'    => self::POST_TYPE,
				'post_status'  => 'private',
				'post_title'   => $name,
				'post_content' => $message,
				'post_author'  => 0,
				'meta_input'   => array(
					'_hushpage_email'   => $email,
					'_hushpage_path'    => '/' . ltrim( (string) wp_parse_url( $path, PHP_URL_PATH ), '/' ),
					'_hushpage_handled' => 0,
				),
			),
			true
		);
		if ( is_wp_error( $id ) ) {
			self::back( 'invalid' );
		}
		self::schedule_cleanup();
		if ( ! empty( $s['contact_notify'] ) ) {
			self::notify( $id, $name, $email, $message );
		}
		self::back( 'ok' );
	}

	/**
	 * Emails the site admin about a new message; "Reply" goes straight to the visitor.
	 *
	 * @param int    $id      Message ID.
	 * @param string $name    Sender name (sanitized: no line breaks).
	 * @param string $email   Sender email (validated).
	 * @param string $message Message.
	 */
	private static function notify( $id, $name, $email, $message ) {
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$subject = sprintf( /* translators: 1: site name, 2: sender name */ __( '[%1$s] New message from %2$s', 'hushpage' ), $site, $name );
		$body    = $message . "\n\n" . sprintf( /* translators: 1: name, 2: email */ __( 'From: %1$s <%2$s>', 'hushpage' ), $name, $email )
			. "\n" . admin_url( 'options-general.php?page=hushpage&tab=messages' );
		$headers = array( 'Reply-To: ' . str_replace( array( "\r", "\n", '<', '>', '"' ), '', $name ) . ' <' . $email . '>' );
		wp_mail( get_option( 'admin_email' ), $subject, $body, $headers );
	}

	// ------------------------------------------------------------------ admin inbox

	/**
	 * Number of messages not yet marked as handled.
	 *
	 * @return int
	 */
	public static function unhandled_count() {
		$q = new WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'private',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => false,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- small private table of messages.
					array(
						'key'   => '_hushpage_handled',
						'value' => '0',
					),
				),
			)
		);
		return (int) $q->found_posts;
	}

	/**
	 * The Messages tab of the settings screen.
	 */
	public static function render_admin() {
		self::cleanup();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only list paging and display flags.
		$paged  = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$notice = isset( $_GET['hushpage-notice'] ) ? sanitize_key( wp_unslash( $_GET['hushpage-notice'] ) ) : '';
		// phpcs:enable
		$q = new WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'private',
				'posts_per_page' => self::PER_PAGE,
				'paged'          => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$s = Hushpage_Settings::get();
		?>
		<?php if ( 'deleted' === $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Message deleted.', 'hushpage' ); ?></p></div>
		<?php endif; ?>
		<p class="description">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of days */
					_n( 'Messages are deleted automatically after %d day.', 'Messages are deleted automatically after %d days.', (int) $s['contact_retention'], 'hushpage' ),
					(int) $s['contact_retention']
				)
			);
			?>
			<?php if ( empty( $s['contact_form'] ) ) : ?>
				<?php esc_html_e( 'The contact form is currently switched off (Settings tab → Contact form).', 'hushpage' ); ?>
			<?php endif; ?>
		</p>
		<?php if ( ! $q->have_posts() ) : ?>
			<p><?php esc_html_e( 'No messages yet.', 'hushpage' ); ?></p>
			<?php
			return;
		endif;
		?>
		<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hushpage_export_messages' ), 'hushpage_export_messages' ) ); ?>"><?php esc_html_e( 'Export all as CSV', 'hushpage' ); ?></a></p>
		<table class="widefat striped hushpage-messages">
			<thead><tr>
				<th scope="col"><?php esc_html_e( 'Received', 'hushpage' ); ?></th>
				<th scope="col"><?php esc_html_e( 'From', 'hushpage' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Message', 'hushpage' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Status', 'hushpage' ); ?></th>
				<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'hushpage' ); ?></span></th>
			</tr></thead>
			<tbody>
			<?php
			foreach ( $q->posts as $msg ) :
				$email   = (string) get_post_meta( $msg->ID, '_hushpage_email', true );
				$handled = (bool) get_post_meta( $msg->ID, '_hushpage_handled', true );
				$act     = function ( $what ) use ( $msg ) {
					return wp_nonce_url( admin_url( 'admin-post.php?action=hushpage_message_action&do=' . $what . '&id=' . $msg->ID ), 'hushpage_message_' . $msg->ID );
				};
				?>
				<tr class="<?php echo esc_attr( $handled ? 'is-handled' : 'is-new' ); ?>">
					<td><?php echo esc_html( get_the_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $msg ) ); ?>
						<br><small><?php echo esc_html( sprintf( /* translators: %s: page path, e.g. /shop/ */ __( 'Sent from: %s', 'hushpage' ), (string) get_post_meta( $msg->ID, '_hushpage_path', true ) ) ); ?></small></td>
					<td><strong><?php echo esc_html( $msg->post_title ); ?></strong><br>
						<a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a></td>
					<td class="hushpage-message-text"><?php echo nl2br( esc_html( $msg->post_content ) ); ?></td>
					<td><?php echo $handled ? esc_html__( 'Handled', 'hushpage' ) : '<strong>' . esc_html__( 'New', 'hushpage' ) . '</strong>'; ?></td>
					<td class="hushpage-message-actions">
						<a href="<?php echo esc_url( $act( $handled ? 'unhandle' : 'handle' ) ); ?>"><?php echo $handled ? esc_html__( 'Mark as new', 'hushpage' ) : esc_html__( 'Mark handled', 'hushpage' ); ?></a>
						| <a class="hushpage-delete" href="<?php echo esc_url( $act( 'delete' ) ); ?>"><?php esc_html_e( 'Delete', 'hushpage' ); ?></a>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$pages = (int) $q->max_num_pages;
		if ( $pages > 1 ) {
			echo '<div class="tablenav"><div class="tablenav-pages">';
			echo wp_kses_post(
				paginate_links(
					array(
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					)
				)
			);
			echo '</div></div>';
		}
	}

	/**
	 * Admin-post: mark handled / new, or delete one message.
	 */
	public static function handle_admin_action() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		check_admin_referer( 'hushpage_message_' . $id );
		$do  = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		$msg = get_post( $id );
		if ( ! $msg || self::POST_TYPE !== $msg->post_type ) {
			wp_die( esc_html__( 'Message not found.', 'hushpage' ), 404 );
		}
		$notice = '';
		if ( 'delete' === $do ) {
			wp_delete_post( $id, true );
			$notice = 'deleted';
		} elseif ( in_array( $do, array( 'handle', 'unhandle' ), true ) ) {
			update_post_meta( $id, '_hushpage_handled', 'handle' === $do ? 1 : 0 );
		}
		wp_safe_redirect( add_query_arg( array_filter( array( 'page' => 'hushpage', 'tab' => 'messages', 'hushpage-notice' => $notice ) ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Spreadsheet apps run cells starting with = + - @ as formulas; prefix them so exported text stays text.
	 *
	 * @param string $value Cell.
	 * @return string
	 */
	private static function csv_cell( $value ) {
		$value = (string) $value;
		return preg_match( '/^[=+\-@\t\r]/', $value ) ? "'" . $value : $value;
	}

	/**
	 * Admin-post: downloads every message as CSV.
	 */
	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hushpage_export_messages' );
		$ids = get_posts(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'private',
				'numberposts' => -1,
				'fields'      => 'ids',
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="hushpage-messages-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a download, not writing a file.
		fputcsv( $out, array( 'received', 'name', 'email', 'message', 'page', 'status' ) );
		foreach ( $ids as $id ) {
			$msg = get_post( $id );
			fputcsv(
				$out,
				array_map(
					array( __CLASS__, 'csv_cell' ),
					array(
						get_post_time( 'c', true, $msg ),
						$msg->post_title,
						get_post_meta( $id, '_hushpage_email', true ),
						$msg->post_content,
						get_post_meta( $id, '_hushpage_path', true ),
						get_post_meta( $id, '_hushpage_handled', true ) ? 'handled' : 'new',
					)
				)
			);
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}

	// ------------------------------------------------------------------ retention and privacy

	/**
	 * Deletes messages older than the retention period (daily cron, and whenever the inbox is opened).
	 */
	public static function cleanup() {
		$s    = Hushpage_Settings::get();
		$days = max( 1, (int) $s['contact_retention'] );
		$old  = get_posts(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'private',
				'numberposts' => 200,
				'fields'      => 'ids',
				'date_query'  => array( array( 'before' => gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ), 'column' => 'post_date_gmt' ) ),
			)
		);
		foreach ( $old as $id ) {
			wp_delete_post( $id, true );
		}
	}

	/**
	 * Messages sent from one email address.
	 *
	 * @param string $email Email.
	 * @param int    $page  Page (1-based).
	 * @return int[]
	 */
	private static function ids_for_email( $email, $page = 1 ) {
		return get_posts(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'private',
				'numberposts' => 100,
				'paged'       => $page,
				'fields'      => 'ids',
				'meta_key'    => '_hushpage_email', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- privacy request lookup.
				'meta_value'  => $email, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- privacy request lookup.
			)
		);
	}

	/**
	 * Tools → Export Personal Data.
	 *
	 * @param array $exporters Exporters.
	 * @return array
	 */
	public static function register_exporter( $exporters ) {
		$exporters['hushpage'] = array(
			'exporter_friendly_name' => __( 'Hushpage maintenance messages', 'hushpage' ),
			'callback'               => array( __CLASS__, 'export_personal_data' ),
		);
		return $exporters;
	}

	/**
	 * Exporter callback.
	 *
	 * @param string $email Email.
	 * @param int    $page  Page.
	 * @return array
	 */
	public static function export_personal_data( $email, $page = 1 ) {
		$items = array();
		$ids   = self::ids_for_email( $email, $page );
		foreach ( $ids as $id ) {
			$msg     = get_post( $id );
			$items[] = array(
				'group_id'    => 'hushpage-messages',
				'group_label' => __( 'Maintenance page messages', 'hushpage' ),
				'item_id'     => 'hushpage-message-' . $id,
				'data'        => array(
					array( 'name' => __( 'Received', 'hushpage' ), 'value' => get_post_time( 'c', true, $msg ) ),
					array( 'name' => __( 'Name', 'hushpage' ), 'value' => $msg->post_title ),
					array( 'name' => __( 'Email', 'hushpage' ), 'value' => $email ),
					array( 'name' => __( 'Message', 'hushpage' ), 'value' => $msg->post_content ),
				),
			);
		}
		return array(
			'data' => $items,
			'done' => count( $ids ) < 100,
		);
	}

	/**
	 * Tools → Erase Personal Data.
	 *
	 * @param array $erasers Erasers.
	 * @return array
	 */
	public static function register_eraser( $erasers ) {
		$erasers['hushpage'] = array(
			'eraser_friendly_name' => __( 'Hushpage maintenance messages', 'hushpage' ),
			'callback'             => array( __CLASS__, 'erase_personal_data' ),
		);
		return $erasers;
	}

	/**
	 * Eraser callback: deletes every message from that address.
	 *
	 * @param string $email Email.
	 * @return array
	 */
	public static function erase_personal_data( $email ) {
		$ids = self::ids_for_email( $email );
		foreach ( $ids as $id ) {
			wp_delete_post( $id, true );
		}
		return array(
			'items_removed'  => count( $ids ) > 0,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => count( $ids ) < 100,
		);
	}

	/**
	 * Suggested text for the site's privacy policy (Settings → Privacy → Policy guide).
	 */
	public static function privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		$s = Hushpage_Settings::get();
		wp_add_privacy_policy_content(
			'Hushpage',
			'<p>' . esc_html(
				sprintf(
					/* translators: %d: number of days */
					__( 'If you use the contact form shown while this site is in maintenance, we store the name, email address and message you send, so we can reply. Messages are deleted automatically after %d days, and you can ask us to export or delete them at any time. Your IP address is not stored.', 'hushpage' ),
					(int) $s['contact_retention']
				)
			) . '</p>'
		);
	}

	/**
	 * Deletes every stored message (uninstall).
	 */
	public static function delete_all() {
		do {
			$ids = get_posts(
				array(
					'post_type'   => self::POST_TYPE,
					'post_status' => 'any',
					'numberposts' => 200,
					'fields'      => 'ids',
				)
			);
			foreach ( $ids as $id ) {
				wp_delete_post( $id, true );
			}
		} while ( $ids );
	}
}
