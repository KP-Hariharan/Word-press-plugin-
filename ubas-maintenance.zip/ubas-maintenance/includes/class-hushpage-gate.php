<?php
/**
 * Decides who sees the maintenance page and serves it with the right HTTP headers.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Front-end gate.
 */
class Hushpage_Gate {

	const COOKIE = 'hushpage_bypass';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_show' ), 0 );
		add_filter( 'rest_authentication_errors', array( __CLASS__, 'rest_guard' ), 99 );
		add_action( Hushpage_Settings::CRON_HOOK, array( 'Hushpage_Settings', 'is_active' ) );
	}

	/**
	 * The current request path relative to the site's home path (so "/shop/" works in subdirectory installs too).
	 *
	 * @return string
	 */
	public static function request_path() {
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		if ( '' !== $home && 0 === strpos( $path, $home ) ) {
			$path = substr( $path, strlen( $home ) );
		}
		return '/' . ltrim( $path, '/' );
	}

	/**
	 * Does maintenance apply to this request? Whole site, or only the listed pages; "always available" pages never.
	 *
	 * @param array $s Settings.
	 * @return bool
	 */
	public static function applies_to_request( $s ) {
		$path = self::request_path();
		if ( Hushpage_Settings::path_matches( $path, $s['exclude_paths'] ) ) {
			return false;
		}
		return 'paths' === $s['scope'] ? Hushpage_Settings::path_matches( $path, $s['paths'] ) : true;
	}

	/**
	 * Can the current visitor see the real site?
	 *
	 * @return bool
	 */
	public static function visitor_can_bypass() {
		$s = Hushpage_Settings::get();
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			if ( user_can( $user, 'manage_options' ) || array_intersect( (array) $user->roles, (array) $s['bypass_roles'] ) ) {
				return true;
			}
		}
		if ( self::has_valid_cookie( $s ) ) {
			return true;
		}
		$ip = self::client_ip();
		if ( $ip && '' !== $s['ip_allowlist'] && in_array( $ip, explode( "\n", $s['ip_allowlist'] ), true ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Visitor IP. Uses REMOTE_ADDR only: forwarded headers can be forged. Hosts behind a proxy
	 * can supply the real address with the hushpage_client_ip filter.
	 *
	 * @return string
	 */
	public static function client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		/**
		 * Filters the visitor IP used for the allowlist.
		 *
		 * @param string $ip REMOTE_ADDR.
		 */
		$ip = (string) apply_filters( 'hushpage_client_ip', $ip );
		return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
	}

	/**
	 * Cookie value: expiry plus an HMAC tied to the current bypass token, so regenerating the
	 * link invalidates every cookie issued before.
	 *
	 * @param array $s       Settings.
	 * @param int   $expires Expiry timestamp.
	 * @return string
	 */
	private static function cookie_value( $s, $expires ) {
		return $expires . '.' . hash_hmac( 'sha256', $expires . '|' . $s['bypass_token'], wp_salt( 'auth' ) );
	}

	/**
	 * Validates the bypass cookie.
	 *
	 * @param array $s Settings.
	 * @return bool
	 */
	private static function has_valid_cookie( $s ) {
		if ( empty( $_COOKIE[ self::COOKIE ] ) ) {
			return false;
		}
		$value = sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) );
		$parts = explode( '.', $value, 2 );
		if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) || (int) $parts[0] < time() ) {
			return false;
		}
		return hash_equals( self::cookie_value( $s, (int) $parts[0] ), $value );
	}

	/**
	 * Secret link: ?hushpage_bypass=TOKEN sets the cookie and reloads the clean URL.
	 *
	 * @param array $s Settings.
	 * @return bool True when a redirect was issued.
	 */
	private static function maybe_accept_link( $s ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a shared secret link, not a form submission.
		if ( empty( $_GET['hushpage_bypass'] ) ) {
			return false;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$token = sanitize_text_field( wp_unslash( $_GET['hushpage_bypass'] ) );
		if ( ! hash_equals( (string) $s['bypass_token'], $token ) ) {
			return false;
		}
		$expires = time() + DAY_IN_SECONDS * (int) $s['bypass_days'];
		setcookie(
			self::COOKIE,
			self::cookie_value( $s, $expires ),
			array(
				'expires'  => $expires,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
		nocache_headers();
		wp_safe_redirect( remove_query_arg( 'hushpage_bypass' ) );
		exit;
	}

	/**
	 * Is an admin previewing the page from the settings screen?
	 *
	 * @return bool
	 */
	private static function is_preview() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified below.
		if ( empty( $_GET['hushpage_preview'] ) || ! current_user_can( 'manage_options' ) ) {
			return false;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$nonce = sanitize_text_field( wp_unslash( isset( $_GET['_wpnonce'] ) ? $_GET['_wpnonce'] : '' ) );
		return (bool) wp_verify_nonce( $nonce, 'hushpage_preview' );
	}

	/**
	 * template_redirect: show the page to everyone who can't bypass.
	 */
	public static function maybe_show() {
		if ( self::is_preview() ) {
			self::render( true );
		}
		if ( ! Hushpage_Settings::is_active() ) {
			return;
		}
		$s = Hushpage_Settings::get();
		self::maybe_accept_link( $s );
		if ( is_robots() || is_favicon() || ! self::applies_to_request( $s ) || self::visitor_can_bypass() ) {
			return;
		}
		/**
		 * Filters whether the current request skips the maintenance page (e.g. a webhook endpoint).
		 *
		 * @param bool $skip Default false.
		 */
		if ( apply_filters( 'hushpage_skip_request', false ) ) {
			return;
		}
		self::render( false );
	}

	/**
	 * Blocks the REST API for logged-out visitors when the owner turns that option off.
	 *
	 * @param mixed $result Existing result.
	 * @return mixed
	 */
	public static function rest_guard( $result ) {
		if ( null !== $result || ! Hushpage_Settings::is_active() ) {
			return $result;
		}
		$s = Hushpage_Settings::get();
		// Page-specific maintenance leaves the REST API alone: it serves the parts of the site that stay live.
		if ( $s['allow_rest'] || 'paths' === $s['scope'] || self::visitor_can_bypass() ) {
			return $result;
		}
		return new WP_Error( 'hushpage_maintenance', __( 'This site is in maintenance mode.', 'hushpage' ), array( 'status' => 503 ) );
	}

	/**
	 * Sends headers and the page, then stops.
	 *
	 * @param bool $preview Admin preview (always 200, never cached or indexed).
	 */
	public static function render( $preview ) {
		$s           = Hushpage_Settings::get();
		$maintenance = 'maintenance' === $s['mode'];

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- standard constant read by caching plugins.
		}
		nocache_headers();
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		if ( $preview ) {
			status_header( 200 );
			header( 'X-Robots-Tag: noindex, nofollow' );
		} elseif ( $maintenance ) {
			// 503 + Retry-After tells search engines this is temporary, so rankings are kept.
			status_header( 503 );
			header( 'Retry-After: ' . (int) $s['retry_after'] * HOUR_IN_SECONDS );
		} else {
			status_header( 200 );
			if ( $s['noindex'] ) {
				header( 'X-Robots-Tag: noindex, nofollow' );
			}
		}
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );

		$template = HUSHPAGE_DIR . 'templates/page.php';
		/**
		 * Filters the template file used for the maintenance page (e.g. a copy in your theme).
		 *
		 * @param string $template Absolute path.
		 */
		$template = (string) apply_filters( 'hushpage_template', $template );
		if ( ! is_readable( $template ) ) {
			$template = HUSHPAGE_DIR . 'templates/page.php';
		}
		$hushpage_settings = $s;
		$hushpage_preview  = $preview;
		include $template;
		exit;
	}
}
