<?php
/**
 * The single settings screen, admin bar indicator and cache purging on change.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin UI.
 */
class Hushpage_Admin {

	const PAGE = 'hushpage';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_hushpage_new_link', array( __CLASS__, 'regenerate_link' ) );
		add_action( 'admin_post_hushpage_post_update', array( __CLASS__, 'post_update' ) );
		add_action( 'admin_post_hushpage_clear_updates', array( __CLASS__, 'clear_updates' ) );
		add_action( 'update_option_' . HUSHPAGE_OPTION, array( __CLASS__, 'after_save' ), 10, 2 );
		add_filter( 'plugin_action_links_' . plugin_basename( HUSHPAGE_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Settings → Maintenance Mode.
	 */
	public static function menu() {
		add_options_page(
			__( 'Maintenance Mode', 'hushpage' ),
			__( 'Maintenance Mode', 'hushpage' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Settings API registration.
	 */
	public static function register() {
		register_setting(
			'hushpage',
			HUSHPAGE_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'Hushpage_Settings', 'sanitize' ),
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Loads assets only on this plugin's screen, using WordPress's bundled colour picker and media library.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public static function assets( $hook ) {
		if ( 'settings_page_' . self::PAGE !== $hook ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'hushpage-admin', HUSHPAGE_URL . 'assets/admin.css', array(), HUSHPAGE_VERSION );
		wp_enqueue_script( 'hushpage-admin', HUSHPAGE_URL . 'assets/admin.js', array( 'jquery', 'wp-color-picker' ), HUSHPAGE_VERSION, true );
		wp_localize_script(
			'hushpage-admin',
			'hushpageAdmin',
			array(
				'chooseImage' => __( 'Choose image', 'hushpage' ),
				'useImage'    => __( 'Use this image', 'hushpage' ),
				'copied'      => __( 'Copied', 'hushpage' ),
			)
		);
	}

	/**
	 * Clears caches whenever the on/off switch or the page itself changes.
	 *
	 * @param mixed $old Previous value.
	 * @param mixed $new New value.
	 */
	public static function after_save( $old, $new ) {
		if ( Hushpage_Settings::$internal_save || $old === $new ) {
			return;
		}
		if ( is_array( $old ) && ! empty( $old['enabled'] ) && is_array( $new ) && empty( $new['enabled'] ) ) {
			Hushpage_Settings::clear_updates(); // the next maintenance starts with a clean timeline.
		}
		Hushpage_Settings::purge_caches( 'settings_saved' );
		Hushpage_Settings::schedule_window( is_array( $new ) ? $new : array() );
		if ( is_array( $new ) && ! empty( $new['contact_form'] ) ) {
			Hushpage_Contact::schedule_cleanup();
		}
	}

	/**
	 * Admin-post: new secret bypass link (invalidates the old link and every cookie it issued).
	 */
	public static function regenerate_link() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hushpage_new_link' );
		$s                 = Hushpage_Settings::get();
		$s['bypass_token'] = Hushpage_Settings::new_token();
		update_option( HUSHPAGE_OPTION, $s, false );
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'hushpage-notice' => 'link' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Admin-post: publish a live status update on the maintenance page.
	 */
	public static function post_update() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hushpage_post_update' );
		$text   = isset( $_POST['hushpage_update'] ) ? sanitize_text_field( wp_unslash( $_POST['hushpage_update'] ) ) : '';
		$notice = Hushpage_Settings::add_update( $text ) ? 'update' : 'update-empty';
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'hushpage-notice' => $notice ), admin_url( 'options-general.php' ) ) . '#hushpage-updates' );
		exit;
	}

	/**
	 * Admin-post: remove all live status updates.
	 */
	public static function clear_updates() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hushpage_clear_updates' );
		Hushpage_Settings::clear_updates();
		wp_safe_redirect( add_query_arg( array( 'page' => self::PAGE, 'hushpage-notice' => 'cleared' ), admin_url( 'options-general.php' ) ) . '#hushpage-updates' );
		exit;
	}

	/**
	 * The live status updates panel (its own form, outside the settings form).
	 */
	private static function render_updates() {
		$updates = Hushpage_Settings::updates();
		?>
		<div class="hushpage-updates" id="hushpage-updates">
			<h2><?php esc_html_e( 'Live status updates', 'hushpage' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Tell visitors how the work is going. Updates appear on the maintenance page right away, and they are cleared when the page switches off.', 'hushpage' ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="hushpage-update-form">
				<input type="hidden" name="action" value="hushpage_post_update">
				<?php wp_nonce_field( 'hushpage_post_update' ); ?>
				<label class="screen-reader-text" for="hushpage-update-text"><?php esc_html_e( 'Status update', 'hushpage' ); ?></label>
				<input type="text" id="hushpage-update-text" class="regular-text" name="hushpage_update" maxlength="<?php echo esc_attr( (string) Hushpage_Settings::UPDATE_LENGTH ); ?>" placeholder="<?php esc_attr_e( 'e.g. Backups done. Updating the shop now.', 'hushpage' ); ?>" required>
				<?php submit_button( __( 'Post update', 'hushpage' ), 'secondary', 'submit', false ); ?>
			</form>
			<?php if ( $updates ) : ?>
				<ul class="hushpage-update-list">
					<?php foreach ( $updates as $update ) : ?>
						<li><time><?php echo esc_html( wp_date( get_option( 'time_format' ), (int) $update['time'] ) ); ?></time> <?php echo esc_html( $update['text'] ); ?></li>
					<?php endforeach; ?>
				</ul>
				<p><a class="button-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hushpage_clear_updates' ), 'hushpage_clear_updates' ) ); ?>"><?php esc_html_e( 'Clear all updates', 'hushpage' ); ?></a></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * "Settings" link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'options-general.php?page=' . self::PAGE );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'hushpage' ) . '</a>' );
		return $links;
	}

	/**
	 * A plain status indicator in the admin bar while maintenance mode is on (not a notice, not dismissable
	 * clutter: it's how you know visitors can't see the site).
	 *
	 * @param WP_Admin_Bar $bar Admin bar.
	 */
	public static function admin_bar( $bar ) {
		if ( ! current_user_can( 'manage_options' ) || ! Hushpage_Settings::is_active() ) {
			return;
		}
		$s = Hushpage_Settings::get();
		$bar->add_node(
			array(
				'id'    => 'hushpage-status',
				'title' => 'coming_soon' === $s['mode'] ? esc_html__( 'Coming soon mode is on', 'hushpage' ) : esc_html__( 'Maintenance mode is on', 'hushpage' ),
				'href'  => admin_url( 'options-general.php?page=' . self::PAGE ),
				'meta'  => array( 'class' => 'hushpage-admin-bar' ),
			)
		);
	}

	/**
	 * Colours the admin bar item, attached to WordPress's own admin-bar stylesheet.
	 */
	public static function admin_bar_style() {
		if ( is_admin_bar_showing() && current_user_can( 'manage_options' ) && Hushpage_Settings::is_active() ) {
			wp_add_inline_style( 'admin-bar', '#wpadminbar .hushpage-admin-bar>.ab-item{background:#b32d2e!important;color:#fff!important}' );
		}
	}

	/**
	 * Media picker field.
	 *
	 * @param string $key   Setting key.
	 * @param int    $id    Attachment ID.
	 * @param string $label Field label.
	 */
	private static function image_field( $key, $id, $label ) {
		$url = $id ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
		?>
		<div class="hushpage-image" data-field="<?php echo esc_attr( $key ); ?>">
			<input type="hidden" name="<?php echo esc_attr( HUSHPAGE_OPTION . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( (string) $id ); ?>">
			<img src="<?php echo esc_url( $url ? $url : '' ); ?>" alt=""<?php echo esc_attr( $url ? '' : ' hidden' ); ?>>
			<button type="button" class="button hushpage-image-choose"><?php echo esc_html( $label ); ?></button>
			<button type="button" class="button-link hushpage-image-remove"<?php echo esc_attr( $id ? '' : ' hidden' ); ?>><?php esc_html_e( 'Remove', 'hushpage' ); ?></button>
		</div>
		<?php
	}

	/**
	 * The cache clearing log table.
	 */
	private static function render_log() {
		$log = Hushpage_Settings::cache_log();
		if ( ! $log ) {
			echo '<p>' . esc_html__( 'Nothing cleared yet. The first entry appears when you save these settings.', 'hushpage' ) . '</p>';
			return;
		}
		$reasons = array(
			'settings_saved'  => __( 'Settings saved', 'hushpage' ),
			'scheduled_start' => __( 'Scheduled start', 'hushpage' ),
			'scheduled_end'   => __( 'Scheduled switch-off', 'hushpage' ),
			'wp_cli'          => __( 'WP-CLI', 'hushpage' ),
			'deactivated'     => __( 'Plugin deactivated', 'hushpage' ),
		);
		?>
		<table class="widefat striped hushpage-log">
			<thead><tr><th scope="col"><?php esc_html_e( 'When', 'hushpage' ); ?></th><th scope="col"><?php esc_html_e( 'Why', 'hushpage' ); ?></th><th scope="col"><?php esc_html_e( 'Caches cleared', 'hushpage' ); ?></th></tr></thead>
			<tbody>
			<?php foreach ( array_slice( $log, 0, Hushpage_Settings::LOG_SIZE ) as $row ) : ?>
				<tr>
					<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $row['time'] ) ); ?></td>
					<td><?php echo esc_html( isset( $reasons[ $row['reason'] ] ) ? $reasons[ $row['reason'] ] : $row['reason'] ); ?></td>
					<td><?php echo esc_html( $row['cleared'] ? implode( ', ', (array) $row['cleared'] ) : __( 'WordPress object cache only (no page cache plugin found)', 'hushpage' ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * The settings screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s       = Hushpage_Settings::get();
		$n       = HUSHPAGE_OPTION;
		$bypass  = add_query_arg( 'hushpage_bypass', rawurlencode( $s['bypass_token'] ), home_url( '/' ) );
		$preview = wp_nonce_url( add_query_arg( 'hushpage_preview', '1', home_url( '/' ) ), 'hushpage_preview' );
		$roles   = wp_roles()->get_names();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag set by our own redirect.
		$notice = isset( $_GET['hushpage-notice'] ) ? sanitize_key( wp_unslash( $_GET['hushpage-notice'] ) ) : '';
		?>
		<div class="wrap hushpage-wrap">
			<h1><?php esc_html_e( 'Maintenance Mode', 'hushpage' ); ?></h1>
			<?php
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab selection only.
			$tab    = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'settings';
			$tab    = in_array( $tab, array( 'messages', 'security' ), true ) ? $tab : 'settings';
			$unread = Hushpage_Contact::unhandled_count();
			?>
			<nav class="nav-tab-wrapper hushpage-tabs">
				<a href="<?php echo esc_url( admin_url( 'options-general.php?page=' . self::PAGE ) ); ?>" class="<?php echo esc_attr( 'settings' === $tab ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>"><?php esc_html_e( 'Settings', 'hushpage' ); ?></a>
				<a href="<?php echo esc_url( admin_url( 'options-general.php?page=' . self::PAGE . '&tab=messages' ) ); ?>" class="<?php echo esc_attr( 'messages' === $tab ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>"><?php esc_html_e( 'Messages', 'hushpage' ); ?>
					<?php if ( $unread ) : ?><span class="hushpage-count"><?php echo esc_html( number_format_i18n( $unread ) ); ?></span><?php endif; ?></a>
				<a href="<?php echo esc_url( admin_url( 'options-general.php?page=' . self::PAGE . '&tab=security' ) ); ?>" class="<?php echo esc_attr( 'security' === $tab ? 'nav-tab nav-tab-active' : 'nav-tab' ); ?>"><?php esc_html_e( 'Password', 'hushpage' ); ?></a>
			</nav>
			<?php
			if ( 'messages' === $tab ) {
				Hushpage_Contact::render_admin();
				echo '</div>';
				return;
			}
			if ( 'security' === $tab ) {
				Hushpage_Lock::render_panel();
				echo '</div>';
				return;
			}
			?>
			<?php if ( 'link' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'New bypass link created. The old link no longer works.', 'hushpage' ); ?></p></div>
			<?php elseif ( 'update' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Update posted. Visitors with the page open will see it within a minute.', 'hushpage' ); ?></p></div>
			<?php elseif ( 'update-empty' === $notice ) : ?>
				<div class="notice notice-warning is-dismissible"><p><?php esc_html_e( 'The update was empty, so nothing was posted.', 'hushpage' ); ?></p></div>
			<?php elseif ( 'cleared' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'All status updates were removed.', 'hushpage' ); ?></p></div>
			<?php endif; ?>
			<?php self::render_updates(); ?>
			<?php if ( defined( 'HUSHPAGE_DISABLE' ) && HUSHPAGE_DISABLE ) : ?>
				<div class="notice notice-warning"><p><?php esc_html_e( 'HUSHPAGE_DISABLE is set in wp-config.php, so the maintenance page is switched off regardless of the setting below.', 'hushpage' ); ?></p></div>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php settings_fields( 'hushpage' ); ?>

				<div class="<?php echo esc_attr( $s['enabled'] ? 'hushpage-status is-on' : 'hushpage-status' ); ?>">
					<label class="hushpage-switch">
						<input type="checkbox" name="<?php echo esc_attr( $n ); ?>[enabled]" value="1" <?php checked( $s['enabled'] ); ?>>
						<span class="hushpage-switch-ui" aria-hidden="true"></span>
						<span class="hushpage-switch-label"><?php esc_html_e( 'Show the maintenance page to visitors', 'hushpage' ); ?></span>
					</label>
					<p class="description"><?php esc_html_e( 'You and the roles you allow below keep seeing the normal site. Page caches are cleared automatically when you save.', 'hushpage' ); ?></p>
					<?php $hushpage_starts = Hushpage_Settings::scheduled_start(); ?>
					<?php if ( $hushpage_starts ) : ?>
						<p class="hushpage-scheduled"><strong><?php echo esc_html( sprintf( /* translators: %s: date and time */ __( 'Scheduled: the page appears on %s.', 'hushpage' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $hushpage_starts ) ) ); ?></strong></p>
					<?php endif; ?>
					<p><a class="button" href="<?php echo esc_url( $preview ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Preview the page', 'hushpage' ); ?></a></p>
				</div>

				<h2><?php esc_html_e( 'Mode', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Type', 'hushpage' ); ?></th>
						<td>
							<fieldset>
								<label><input type="radio" name="<?php echo esc_attr( $n ); ?>[mode]" value="maintenance" <?php checked( 'maintenance', $s['mode'] ); ?>> <?php esc_html_e( 'Maintenance: the site is temporarily down (search engines receive 503 “try again later”, so rankings are kept).', 'hushpage' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $n ); ?>[mode]" value="coming_soon" <?php checked( 'coming_soon', $s['mode'] ); ?>> <?php esc_html_e( 'Coming soon: the site hasn’t launched yet (normal 200 response).', 'hushpage' ); ?></label>
							</fieldset>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="hushpage-start"><?php esc_html_e( 'Switch on automatically', 'hushpage' ); ?></label></th>
						<td><input type="datetime-local" id="hushpage-start" name="<?php echo esc_attr( $n ); ?>[start_at]" value="<?php echo esc_attr( $s['start_at'] ); ?>">
							<p class="description"><?php esc_html_e( 'Optional. Plan a maintenance window: turn the switch on, set a start (and end) time, and the page appears and disappears by itself.', 'hushpage' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="hushpage-end"><?php esc_html_e( 'Switch off automatically', 'hushpage' ); ?></label></th>
						<td><input type="datetime-local" id="hushpage-end" name="<?php echo esc_attr( $n ); ?>[end_at]" value="<?php echo esc_attr( $s['end_at'] ); ?>">
							<p class="description"><?php echo esc_html( sprintf( /* translators: %s: site time zone */ __( 'Optional. Site time zone: %s.', 'hushpage' ), wp_timezone_string() ) ); ?></p></td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Where it applies', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Pages', 'hushpage' ); ?></th>
						<td>
							<fieldset>
								<label><input type="radio" name="<?php echo esc_attr( $n ); ?>[scope]" value="site" <?php checked( 'site', $s['scope'] ); ?>> <?php esc_html_e( 'The whole site', 'hushpage' ); ?></label><br>
								<label><input type="radio" name="<?php echo esc_attr( $n ); ?>[scope]" value="paths" <?php checked( 'paths', $s['scope'] ); ?>> <?php esc_html_e( 'Only these pages (the rest of the site stays live):', 'hushpage' ); ?></label>
							</fieldset>
							<textarea id="hushpage-paths" class="regular-text code" rows="3" aria-label="<?php esc_attr_e( 'Pages in maintenance', 'hushpage' ); ?>" placeholder="/shop/&#10;/checkout/" name="<?php echo esc_attr( $n ); ?>[paths]"><?php echo esc_textarea( $s['paths'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'One path or page address per line. "/shop" also covers everything under it, such as /shop/cart/.', 'hushpage' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="hushpage-exclude"><?php esc_html_e( 'Always available', 'hushpage' ); ?></label></th>
						<td><textarea id="hushpage-exclude" class="regular-text code" rows="3" placeholder="/privacy-policy/&#10;/contact/" name="<?php echo esc_attr( $n ); ?>[exclude_paths]"><?php echo esc_textarea( $s['exclude_paths'] ); ?></textarea>
							<p class="description"><?php esc_html_e( 'Pages visitors can always open, even during maintenance (for example your privacy policy or a payment page).', 'hushpage' ); ?></p></td>
					</tr>
				</table>

				<h2><?php esc_html_e( 'Page content', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hushpage-title"><?php esc_html_e( 'Browser tab title', 'hushpage' ); ?></label></th>
						<td><input type="text" class="regular-text" id="hushpage-title" name="<?php echo esc_attr( $n ); ?>[page_title]" value="<?php echo esc_attr( $s['page_title'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hushpage-headline"><?php esc_html_e( 'Headline', 'hushpage' ); ?></label></th>
						<td><input type="text" class="large-text" id="hushpage-headline" name="<?php echo esc_attr( $n ); ?>[headline]" value="<?php echo esc_attr( $s['headline'] ); ?>"></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Message', 'hushpage' ); ?></th>
						<td><?php wp_editor( $s['message'], 'hushpage_message', array( 'textarea_name' => $n . '[message]', 'teeny' => true, 'media_buttons' => false, 'textarea_rows' => 6 ) ); ?></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Logo', 'hushpage' ); ?></th>
						<td><?php self::image_field( 'logo_id', (int) $s['logo_id'], __( 'Choose logo', 'hushpage' ) ); ?></td></tr>
					<tr><th scope="row"><label for="hushpage-email"><?php esc_html_e( 'Contact email', 'hushpage' ); ?></label></th>
						<td><input type="email" class="regular-text" id="hushpage-email" name="<?php echo esc_attr( $n ); ?>[contact_email]" value="<?php echo esc_attr( $s['contact_email'] ); ?>">
							<p class="description"><?php esc_html_e( 'Optional. Shown on the page, encoded against spam bots.', 'hushpage' ); ?></p></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Social links', 'hushpage' ); ?></th>
						<td>
							<?php for ( $i = 0; $i < 4; $i++ ) : ?>
								<input type="url" class="regular-text hushpage-social" placeholder="https://" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: link number */ __( 'Social link %d', 'hushpage' ), $i + 1 ) ); ?>" name="<?php echo esc_attr( $n ); ?>[social_links][]" value="<?php echo esc_attr( isset( $s['social_links'][ $i ] ) ? $s['social_links'][ $i ] : '' ); ?>"><br>
							<?php endfor; ?>
						</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Countdown', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[show_countdown]" value="1" <?php checked( $s['show_countdown'] ); ?>> <?php esc_html_e( 'Show a countdown to', 'hushpage' ); ?></label>
							<input type="datetime-local" aria-label="<?php esc_attr_e( 'Countdown end', 'hushpage' ); ?>" name="<?php echo esc_attr( $n ); ?>[countdown_to]" value="<?php echo esc_attr( $s['countdown_to'] ); ?>"></td></tr>
					<tr><th scope="row"><label for="hushpage-footer"><?php esc_html_e( 'Footer text', 'hushpage' ); ?></label></th>
						<td><input type="text" class="large-text" id="hushpage-footer" name="<?php echo esc_attr( $n ); ?>[footer_text]" value="<?php echo esc_attr( $s['footer_text'] ); ?>"></td></tr>
				</table>

				<h2><?php esc_html_e( 'Design', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Colours', 'hushpage' ); ?></th>
						<td class="hushpage-colors">
							<?php
							foreach ( array( 'bg_color' => __( 'Background', 'hushpage' ), 'text_color' => __( 'Text', 'hushpage' ), 'accent_color' => __( 'Links and accents', 'hushpage' ) ) as $key => $label ) :
								?>
								<div class="hushpage-color-field"><span class="hushpage-color-label" id="<?php echo esc_attr( 'hushpage-label-' . $key ); ?>"><?php echo esc_html( $label ); ?></span>
									<input type="text" class="hushpage-color" aria-labelledby="<?php echo esc_attr( 'hushpage-label-' . $key ); ?>" name="<?php echo esc_attr( $n . '[' . $key . ']' ); ?>" value="<?php echo esc_attr( $s[ $key ] ); ?>" data-default-color="<?php echo esc_attr( Hushpage_Settings::defaults()[ $key ] ); ?>"></div>
							<?php endforeach; ?>
						</td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Background image', 'hushpage' ); ?></th>
						<td><?php self::image_field( 'bg_image_id', (int) $s['bg_image_id'], __( 'Choose image', 'hushpage' ) ); ?></td></tr>
				</table>

				<h2><?php esc_html_e( 'Who can see the real site', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Logged-in roles', 'hushpage' ); ?></th>
						<td><fieldset>
							<?php foreach ( $roles as $slug => $name ) : ?>
								<label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[bypass_roles][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $s['bypass_roles'], true ) ); ?> <?php disabled( 'administrator', $slug ); ?>> <?php echo esc_html( translate_user_role( $name ) ); ?></label><br>
							<?php endforeach; ?>
							<p class="description"><?php esc_html_e( 'Administrators always see the real site, so you can never lock yourself out.', 'hushpage' ); ?></p>
						</fieldset></td></tr>
					<tr><th scope="row"><label for="hushpage-link"><?php esc_html_e( 'Secret link', 'hushpage' ); ?></label></th>
						<td><input type="text" id="hushpage-link" class="large-text code" readonly value="<?php echo esc_url( $bypass ); ?>">
							<p><button type="button" class="button hushpage-copy" data-target="hushpage-link"><?php esc_html_e( 'Copy link', 'hushpage' ); ?></button>
								<a class="button-link" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hushpage_new_link' ), 'hushpage_new_link' ) ); ?>"><?php esc_html_e( 'Create a new link (the old one stops working)', 'hushpage' ); ?></a></p>
							<p class="description">
								<?php esc_html_e( 'Share it with clients or testers: anyone who opens it sees the real site for', 'hushpage' ); ?>
								<input type="number" min="1" max="90" class="small-text" aria-label="<?php esc_attr_e( 'Days', 'hushpage' ); ?>" name="<?php echo esc_attr( $n ); ?>[bypass_days]" value="<?php echo esc_attr( (string) $s['bypass_days'] ); ?>">
								<?php esc_html_e( 'days, without logging in.', 'hushpage' ); ?>
							</p></td></tr>
					<tr><th scope="row"><label for="hushpage-ips"><?php esc_html_e( 'Allowed IP addresses', 'hushpage' ); ?></label></th>
						<td><textarea id="hushpage-ips" class="regular-text code" rows="3" name="<?php echo esc_attr( $n ); ?>[ip_allowlist]"><?php echo esc_textarea( $s['ip_allowlist'] ); ?></textarea>
							<p class="description"><?php echo esc_html( sprintf( /* translators: %s: visitor IP address */ __( 'One per line. Your current address is %s.', 'hushpage' ), Hushpage_Gate::client_ip() ? Hushpage_Gate::client_ip() : __( 'unknown', 'hushpage' ) ) ); ?></p></td></tr>
				</table>

				<h2><?php esc_html_e( 'Search engines and integrations', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><label for="hushpage-retry"><?php esc_html_e( 'Expected downtime', 'hushpage' ); ?></label></th>
						<td><input type="number" id="hushpage-retry" min="1" max="168" class="small-text" name="<?php echo esc_attr( $n ); ?>[retry_after]" value="<?php echo esc_attr( (string) $s['retry_after'] ); ?>"> <?php esc_html_e( 'hours (sent to search engines as Retry-After in maintenance mode)', 'hushpage' ); ?></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Coming soon indexing', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[noindex]" value="1" <?php checked( $s['noindex'] ); ?>> <?php esc_html_e( 'Ask search engines not to index the coming soon page', 'hushpage' ); ?></label></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'REST API', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[allow_rest]" value="1" <?php checked( $s['allow_rest'] ); ?>> <?php esc_html_e( 'Keep the REST API available to logged-out visitors (needed by some forms, apps and payment webhooks)', 'hushpage' ); ?></label></td></tr>
				</table>

				<h2><?php esc_html_e( 'Contact form', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Form', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[contact_form]" value="1" <?php checked( $s['contact_form'] ); ?>> <?php esc_html_e( 'Show a "Leave us a message" form on the maintenance page', 'hushpage' ); ?></label>
							<p class="description"><?php esc_html_e( 'Messages appear under the Messages tab. Spam is filtered without any outside service, and visitors must agree before anything is stored.', 'hushpage' ); ?></p></td></tr>
					<tr><th scope="row"><label for="hushpage-contact-heading"><?php esc_html_e( 'Form heading', 'hushpage' ); ?></label></th>
						<td><input type="text" id="hushpage-contact-heading" class="regular-text" name="<?php echo esc_attr( $n ); ?>[contact_heading]" value="<?php echo esc_attr( $s['contact_heading'] ); ?>"></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'New message alerts', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[contact_notify]" value="1" <?php checked( $s['contact_notify'] ); ?>> <?php echo esc_html( sprintf( /* translators: %s: admin email address */ __( 'Email each new message to %s (replies go straight to the visitor)', 'hushpage' ), get_option( 'admin_email' ) ) ); ?></label></td></tr>
					<tr><th scope="row"><label for="hushpage-retention"><?php esc_html_e( 'Keep messages for', 'hushpage' ); ?></label></th>
						<td><input type="number" id="hushpage-retention" min="1" max="365" class="small-text" name="<?php echo esc_attr( $n ); ?>[contact_retention]" value="<?php echo esc_attr( (string) $s['contact_retention'] ); ?>"> <?php esc_html_e( 'days, then they are deleted automatically', 'hushpage' ); ?></td></tr>
				</table>

				<h2><?php esc_html_e( 'Notifications', 'hushpage' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr><th scope="row"><?php esc_html_e( 'Email alerts', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[notify_email]" value="1" <?php checked( $s['notify_email'] ); ?>> <?php echo esc_html( sprintf( /* translators: %s: admin email address */ __( 'Email %s when a scheduled maintenance window starts or ends', 'hushpage' ), get_option( 'admin_email' ) ) ); ?></label></td></tr>
					<tr><th scope="row"><?php esc_html_e( 'Live page', 'hushpage' ); ?></th>
						<td><label><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[live_refresh]" value="1" <?php checked( $s['live_refresh'] ); ?>> <?php esc_html_e( 'Keep visitors\' open pages current: new status updates appear, and the page reloads into your site as soon as maintenance ends', 'hushpage' ); ?></label>
							<p class="description"><?php esc_html_e( 'The page checks itself once a minute while the browser tab is visible. No external services are used.', 'hushpage' ); ?></p></td></tr>
				</table>

				<?php submit_button(); ?>
			</form>

			<h2><?php esc_html_e( 'Cache clearing log', 'hushpage' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Every time the page switches on or off, Hushpage clears the page caches it can reach, so nobody sees a stale page. The last 20 runs:', 'hushpage' ); ?></p>
			<?php self::render_log(); ?>
			<p class="description"><?php esc_html_e( 'Locked out by another plugin? Add define( \'HUSHPAGE_DISABLE\', true ); to wp-config.php to switch this page off, or run: wp hushpage disable', 'hushpage' ); ?></p>
		</div>
		<?php
	}
}
