<?php
/**
 * Password in front of the Hushpage settings, with a "Password" tab to set or change it.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Password lock for the settings screens.
 */
class Hushpage_Lock {

	const OPTION     = 'hushpage_lock_hash';
	const META       = 'hpl_unlock';
	const MAX_FAILS  = 5;
	const LOCKOUT    = 900; // Seconds locked out after too many wrong passwords.
	const MIN_LENGTH = 8;

	/**
	 * admin-post actions of Hushpage that sit behind the password. The public contact form is not listed on purpose.
	 */
	const GUARDED_ACTIONS = array(
		'hushpage_new_link',
		'hushpage_post_update',
		'hushpage_clear_updates',
		'hushpage_message_action',
		'hushpage_export_messages',
	);

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'maybe_reset' ) );
		add_action( 'admin_init', array( __CLASS__, 'guard' ), 1 );
		add_action( 'admin_notices', array( __CLASS__, 'unlocked_notice' ) );
		add_action( 'admin_post_hpl_unlock', array( __CLASS__, 'handle_unlock' ) );
		add_action( 'admin_post_hpl_lock_now', array( __CLASS__, 'handle_lock_now' ) );
		add_action( 'admin_post_hpl_set_password', array( __CLASS__, 'handle_set_password' ) );
	}

	/* ------------------------------------------------------------------ state */

	/**
	 * Has a password been set?
	 *
	 * @return bool
	 */
	public static function has_password() {
		return '' !== (string) get_option( self::OPTION, '' );
	}

	/**
	 * Idle time before the settings lock again.
	 *
	 * @return int Seconds.
	 */
	private static function timeout() {
		return (int) apply_filters( 'hushpage_lock_timeout', 30 * MINUTE_IN_SECONDS );
	}

	/**
	 * Ties an unlock to the current login session.
	 *
	 * @return string
	 */
	private static function token_hash() {
		return hash( 'sha256', wp_get_session_token() . wp_salt( 'auth' ) );
	}

	/**
	 * Has the current user entered the password recently?
	 *
	 * @return bool
	 */
	public static function is_unlocked() {
		$m = get_user_meta( get_current_user_id(), self::META, true );
		return is_array( $m ) && isset( $m['exp'], $m['h'] ) && (int) $m['exp'] > time() && hash_equals( (string) $m['h'], self::token_hash() );
	}

	/**
	 * Mark the current user as unlocked, or extend the window.
	 */
	private static function unlock() {
		update_user_meta( get_current_user_id(), self::META, array( 'exp' => time() + self::timeout(), 'h' => self::token_hash() ) );
	}

	/**
	 * Check a password against the stored hash.
	 *
	 * @param string $plain Password typed by the user.
	 * @return bool
	 */
	private static function check_password( $plain ) {
		$hash = (string) get_option( self::OPTION, '' );
		return '' !== $hash && '' !== $plain && wp_check_password( $plain, $hash );
	}

	/* ------------------------------------------------------------ rate limit */

	/**
	 * Transient key for the current user's failed attempts.
	 *
	 * @return string
	 */
	private static function fail_key() {
		return 'hpl_fail_' . get_current_user_id();
	}

	/**
	 * Seconds left in a lockout, or 0.
	 *
	 * @return int
	 */
	private static function locked_out_for() {
		$f = get_transient( self::fail_key() );
		return ( is_array( $f ) && ! empty( $f['until'] ) && $f['until'] > time() ) ? (int) $f['until'] - time() : 0;
	}

	/**
	 * Count a wrong password and start a lockout after too many.
	 */
	private static function record_fail() {
		$f     = get_transient( self::fail_key() );
		$n     = ( is_array( $f ) && isset( $f['n'] ) ? (int) $f['n'] : 0 ) + 1;
		$until = $n >= self::MAX_FAILS ? time() + self::LOCKOUT : 0;
		set_transient( self::fail_key(), array( 'n' => $until ? 0 : $n, 'until' => $until ), self::LOCKOUT * 2 );
	}

	/**
	 * Forget failed attempts.
	 */
	private static function clear_fails() {
		delete_transient( self::fail_key() );
	}

	/* ----------------------------------------------------------------- guard */

	/**
	 * Is this request one of Hushpage's admin screens or actions?
	 *
	 * @return bool
	 */
	private static function is_protected_request() {
		global $pagenow;
		// phpcs:disable WordPress.Security.NonceVerification
		if ( 'options-general.php' === $pagenow && isset( $_REQUEST['page'] ) && Hushpage_Admin::PAGE === sanitize_key( wp_unslash( $_REQUEST['page'] ) ) ) {
			return true;
		}
		if ( 'options.php' === $pagenow && isset( $_POST['option_page'] ) && 'hushpage' === sanitize_key( wp_unslash( $_POST['option_page'] ) ) ) {
			return true;
		}
		if ( 'admin-post.php' === $pagenow && isset( $_REQUEST['action'] ) && in_array( sanitize_key( wp_unslash( $_REQUEST['action'] ) ), self::GUARDED_ACTIONS, true ) ) {
			return true;
		}
		// phpcs:enable
		return false;
	}

	/**
	 * Show the password screen instead of a protected request until the password is entered.
	 */
	public static function guard() {
		if ( ! self::has_password() || ! is_user_logged_in() || ! current_user_can( 'manage_options' ) || ! self::is_protected_request() ) {
			return;
		}
		if ( self::is_unlocked() ) {
			self::unlock(); // Idle timeout: every protected request extends the window.
			return;
		}
		self::render_lock_screen();
	}

	/**
	 * Is the current request a plain page view (not a form post)?
	 *
	 * @return bool
	 */
	private static function is_get() {
		return 'GET' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET' );
	}

	/**
	 * Where to send the user after unlocking: the Hushpage screen they asked for, never an arbitrary URL.
	 *
	 * @return string
	 */
	private static function return_url() {
		global $pagenow;
		$url = admin_url( 'options-general.php?page=' . Hushpage_Admin::PAGE );
		if ( ! self::is_get() || 'options-general.php' !== $pagenow ) {
			return $url; // A blocked save or action cannot be replayed, the user repeats it after unlocking.
		}
		// phpcs:ignore WordPress.Security.NonceVerification
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : '';
		return in_array( $tab, array( 'messages', 'security' ), true ) ? $url . '&tab=' . $tab : $url;
	}

	/**
	 * Standalone password page.
	 */
	private static function render_lock_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification
		$err  = isset( $_GET['hpl_err'] ) ? sanitize_key( wp_unslash( $_GET['hpl_err'] ) ) : '';
		$wait = self::locked_out_for();

		$msg = '';
		if ( $wait ) {
			/* translators: %d: minutes */
			$msg = sprintf( __( 'Too many wrong passwords. Try again in %d minute(s).', 'hushpage' ), (int) ceil( $wait / 60 ) );
		} elseif ( 'bad' === $err ) {
			$msg = __( 'That password is not correct.', 'hushpage' );
		} elseif ( ! self::is_get() ) {
			$msg = __( 'That change was not saved because the settings are locked. Enter the password, then make the change again.', 'hushpage' );
		}

		nocache_headers();
		status_header( 200 );
		header( 'Content-Type: text/html; charset=utf-8' );
		?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php esc_html_e( 'Maintenance Mode is locked', 'hushpage' ); ?></title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f0f0f1;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#1d2327}
.box{width:100%;max-width:380px;margin:24px;background:#fff;border:1px solid #c3c4c7;border-top:4px solid #2271b1;border-radius:4px;padding:28px 28px 24px;box-shadow:0 1px 3px rgba(0,0,0,.08)}
h1{font-size:20px;margin:0 0 6px}p{margin:0 0 16px;color:#50575e;font-size:14px;line-height:1.5}
label{display:block;font-weight:600;font-size:13px;margin-bottom:6px}
input[type=password]{width:100%;box-sizing:border-box;padding:9px 10px;font-size:15px;border:1px solid #8c8f94;border-radius:4px}
button{margin-top:14px;width:100%;padding:10px;font-size:15px;font-weight:600;color:#fff;background:#2271b1;border:0;border-radius:4px;cursor:pointer}
button:hover{background:#135e96}button:disabled{opacity:.6;cursor:not-allowed}.err{background:#fcf0f1;border-left:4px solid #d63638;padding:8px 10px;margin-bottom:14px;font-size:13px}
a{color:#2271b1;font-size:13px}.back{margin-top:16px;text-align:center}
</style>
</head>
<body>
<div class="box">
	<h1><?php esc_html_e( 'Maintenance Mode is locked', 'hushpage' ); ?></h1>
	<p><?php esc_html_e( 'Enter the password to open the maintenance settings.', 'hushpage' ); ?></p>
	<?php if ( $msg ) : ?><div class="err" role="alert"><?php echo esc_html( $msg ); ?></div><?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="hpl_unlock">
		<?php wp_nonce_field( 'hpl_unlock' ); ?>
		<input type="hidden" name="redirect_to" value="<?php echo esc_attr( self::return_url() ); ?>">
		<label for="hpl_password"><?php esc_html_e( 'Password', 'hushpage' ); ?></label>
		<input type="password" id="hpl_password" name="hpl_password" autocomplete="current-password" autofocus required<?php echo $wait ? ' disabled' : ''; ?>>
		<button type="submit"<?php echo $wait ? ' disabled' : ''; ?>><?php esc_html_e( 'Unlock', 'hushpage' ); ?></button>
	</form>
	<div class="back"><a href="<?php echo esc_url( admin_url() ); ?>"><?php esc_html_e( 'Back to the dashboard', 'hushpage' ); ?></a></div>
</div>
</body>
</html>
		<?php
		exit;
	}

	/* -------------------------------------------------------------- handlers */

	/**
	 * Redirect to the Password tab with a notice.
	 *
	 * @param string $notice Notice key.
	 */
	private static function back_to_tab( $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => Hushpage_Admin::PAGE, 'tab' => 'security', 'hpl_notice' => $notice ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	/**
	 * Admin-post: check the password and unlock.
	 */
	public static function handle_unlock() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hpl_unlock' );

		$fallback = admin_url( 'options-general.php?page=' . Hushpage_Admin::PAGE );
		$to       = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
		$to       = remove_query_arg( 'hpl_err', wp_validate_redirect( $to, $fallback ) );

		if ( self::locked_out_for() ) {
			wp_safe_redirect( $to );
			exit;
		}
		$plain = isset( $_POST['hpl_password'] ) ? (string) wp_unslash( $_POST['hpl_password'] ) : '';
		if ( self::check_password( $plain ) ) {
			self::clear_fails();
			self::unlock();
			wp_safe_redirect( $to );
			exit;
		}
		self::record_fail();
		wp_safe_redirect( add_query_arg( 'hpl_err', 'bad', $to ) );
		exit;
	}

	/**
	 * Admin-post: lock the settings again right away.
	 */
	public static function handle_lock_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hpl_lock_now' );
		delete_user_meta( get_current_user_id(), self::META );
		wp_safe_redirect( admin_url( 'options-general.php?page=' . Hushpage_Admin::PAGE ) );
		exit;
	}

	/**
	 * Admin-post: set the first password, or change it. Changing always needs the current password.
	 */
	public static function handle_set_password() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'hushpage' ), 403 );
		}
		check_admin_referer( 'hpl_set_password' );

		$new     = isset( $_POST['hpl_new'] ) ? (string) wp_unslash( $_POST['hpl_new'] ) : '';
		$confirm = isset( $_POST['hpl_confirm'] ) ? (string) wp_unslash( $_POST['hpl_confirm'] ) : '';

		if ( self::has_password() ) {
			if ( self::locked_out_for() ) {
				self::back_to_tab( 'rate' );
			}
			$current = isset( $_POST['hpl_current'] ) ? (string) wp_unslash( $_POST['hpl_current'] ) : '';
			if ( ! self::check_password( $current ) ) {
				self::record_fail();
				self::back_to_tab( 'badcurrent' );
			}
			self::clear_fails();
		}
		if ( strlen( $new ) < self::MIN_LENGTH ) {
			self::back_to_tab( 'short' );
		}
		if ( ! hash_equals( $new, $confirm ) ) {
			self::back_to_tab( 'mismatch' );
		}

		update_option( self::OPTION, wp_hash_password( $new ), false );
		delete_metadata( 'user', 0, self::META, '', true ); // Everyone has to use the new password.
		self::unlock();
		self::back_to_tab( 'saved' );
	}

	/* ------------------------------------------------------------ admin bits */

	/**
	 * "Unlocked" bar with lock-now and change-password links on the settings screen.
	 */
	public static function unlocked_notice() {
		// phpcs:ignore WordPress.Security.NonceVerification
		if ( ! self::has_password() || ! isset( $_GET['page'] ) || Hushpage_Admin::PAGE !== sanitize_key( wp_unslash( $_GET['page'] ) ) || ! self::is_unlocked() ) {
			return;
		}
		printf(
			'<div class="notice notice-info"><p>%s <a href="%s">%s</a> | <a href="%s">%s</a></p></div>',
			esc_html__( 'Settings are unlocked.', 'hushpage' ),
			esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hpl_lock_now' ), 'hpl_lock_now' ) ),
			esc_html__( 'Lock now', 'hushpage' ),
			esc_url( admin_url( 'options-general.php?page=' . Hushpage_Admin::PAGE . '&tab=security' ) ),
			esc_html__( 'Change password', 'hushpage' )
		);
	}

	/**
	 * The Password tab.
	 */
	public static function render_panel() {
		// phpcs:ignore WordPress.Security.NonceVerification
		$notice = isset( $_GET['hpl_notice'] ) ? sanitize_key( wp_unslash( $_GET['hpl_notice'] ) ) : '';
		$texts  = array(
			'saved'      => array( 'success', __( 'Password saved. Use it the next time you open the maintenance settings.', 'hushpage' ) ),
			'badcurrent' => array( 'error', __( 'The current password is not correct, so nothing was changed.', 'hushpage' ) ),
			'rate'       => array( 'error', __( 'Too many wrong passwords. Try again later.', 'hushpage' ) ),
			/* translators: %d: minimum length */
			'short'      => array( 'error', sprintf( __( 'The new password must be at least %d characters.', 'hushpage' ), self::MIN_LENGTH ) ),
			'mismatch'   => array( 'error', __( 'The two new passwords do not match.', 'hushpage' ) ),
		);
		$has = self::has_password();
		?>
		<?php if ( isset( $texts[ $notice ] ) ) : ?>
			<div class="notice notice-<?php echo esc_attr( $texts[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $texts[ $notice ][1] ); ?></p></div>
		<?php endif; ?>
		<p>
			<?php
			if ( $has ) {
				/* translators: %d: minutes */
				echo esc_html( sprintf( __( 'The maintenance settings are protected by a password. They lock again after %d minutes of inactivity.', 'hushpage' ), (int) ( self::timeout() / MINUTE_IN_SECONDS ) ) );
			} else {
				esc_html_e( 'No password is set yet, so the maintenance settings are open. Set one below to lock them.', 'hushpage' );
			}
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:420px">
			<input type="hidden" name="action" value="hpl_set_password">
			<?php wp_nonce_field( 'hpl_set_password' ); ?>
			<h2><?php echo esc_html( $has ? __( 'Change password', 'hushpage' ) : __( 'Set a password', 'hushpage' ) ); ?></h2>
			<?php if ( $has ) : ?>
				<p><label for="hpl_current"><strong><?php esc_html_e( 'Current password', 'hushpage' ); ?></strong></label><br>
				<input type="password" class="regular-text" id="hpl_current" name="hpl_current" autocomplete="current-password" required></p>
			<?php endif; ?>
			<p><label for="hpl_new"><strong><?php esc_html_e( 'New password', 'hushpage' ); ?></strong></label><br>
			<input type="password" class="regular-text" id="hpl_new" name="hpl_new" autocomplete="new-password" minlength="<?php echo (int) self::MIN_LENGTH; ?>" required></p>
			<p><label for="hpl_confirm"><strong><?php esc_html_e( 'Repeat new password', 'hushpage' ); ?></strong></label><br>
			<input type="password" class="regular-text" id="hpl_confirm" name="hpl_confirm" autocomplete="new-password" minlength="<?php echo (int) self::MIN_LENGTH; ?>" required></p>
			<?php submit_button( $has ? __( 'Change password', 'hushpage' ) : __( 'Set password', 'hushpage' ) ); ?>
		</form>
		<?php if ( $has ) : ?>
			<p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=hpl_lock_now' ), 'hpl_lock_now' ) ); ?>"><?php esc_html_e( 'Lock now', 'hushpage' ); ?></a></p>
		<?php endif; ?>
		<p class="description"><?php esc_html_e( 'Lost the password? Add define( \'HUSHPAGE_LOCK_RESET\', true ); to wp-config.php, open any admin page once, then remove the line.', 'hushpage' ); ?></p>
		<?php
	}

	/**
	 * Emergency reset through wp-config.php (needs file access, so it is safe to offer).
	 */
	public static function maybe_reset() {
		if ( ! defined( 'HUSHPAGE_LOCK_RESET' ) || ! HUSHPAGE_LOCK_RESET ) {
			return;
		}
		delete_option( self::OPTION );
		add_action(
			'admin_notices',
			static function () {
				echo '<div class="notice notice-warning"><p>' . esc_html__( 'The settings password was cleared because HUSHPAGE_LOCK_RESET is set. Remove that line from wp-config.php, then set a new password on the Password tab.', 'hushpage' ) . '</p></div>';
			}
		);
	}
}
