<?php
/**
 * Site Health checks (Tools → Site Health): maintenance left on too long, and page caches Hushpage can't clear.
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site Health integration.
 */
class Hushpage_Health {

	const WARN_DAYS     = 7;
	const CRITICAL_DAYS = 30;

	/**
	 * Hooks.
	 */
	public static function init() {
		add_filter( 'site_status_tests', array( __CLASS__, 'register' ) );
	}

	/**
	 * Adds the direct tests.
	 *
	 * @param array $tests Site Health tests.
	 * @return array
	 */
	public static function register( $tests ) {
		$tests['direct']['hushpage_duration'] = array(
			'label' => __( 'Maintenance page duration', 'hushpage' ),
			'test'  => array( __CLASS__, 'test_duration' ),
		);
		$tests['direct']['hushpage_cache'] = array(
			'label' => __( 'Page cache clearing', 'hushpage' ),
			'test'  => array( __CLASS__, 'test_cache' ),
		);
		return $tests;
	}

	/**
	 * Common result fields.
	 *
	 * @param string $test        Test id.
	 * @param string $status      good|recommended|critical.
	 * @param string $label       Headline.
	 * @param string $description Plain-text explanation.
	 * @return array
	 */
	private static function result( $test, $status, $label, $description ) {
		return array(
			'label'       => $label,
			'status'      => $status,
			'badge'       => array(
				'label' => __( 'Hushpage', 'hushpage' ),
				'color' => 'good' === $status ? 'blue' : ( 'critical' === $status ? 'red' : 'orange' ),
			),
			'description' => '<p>' . esc_html( $description ) . '</p>',
			'actions'     => sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'options-general.php?page=hushpage' ) ),
				esc_html__( 'Open Hushpage settings', 'hushpage' )
			),
			'test'        => $test,
		);
	}

	/**
	 * Warns when maintenance mode (503) has been on for days: search engines start dropping pages
	 * that stay "temporarily unavailable" for weeks.
	 *
	 * @return array
	 */
	public static function test_duration() {
		$s = Hushpage_Settings::get();
		if ( ! Hushpage_Settings::is_active() || 'maintenance' !== $s['mode'] || empty( $s['enabled_since'] ) ) {
			return self::result( 'hushpage_duration', 'good', __( 'No long-running maintenance page', 'hushpage' ),
				__( 'Search engines are not being shown a long "temporarily unavailable" response.', 'hushpage' ) );
		}
		$days = (int) floor( ( time() - (int) $s['enabled_since'] ) / DAY_IN_SECONDS );
		if ( $days < self::WARN_DAYS ) {
			return self::result( 'hushpage_duration', 'good', __( 'Maintenance page recently switched on', 'hushpage' ),
				__( 'Short maintenance periods are safe for search rankings.', 'hushpage' ) );
		}
		return self::result(
			'hushpage_duration',
			$days >= self::CRITICAL_DAYS ? 'critical' : 'recommended',
			/* translators: %d: number of days */
			sprintf( _n( 'The maintenance page has been on for %d day', 'The maintenance page has been on for %d days', $days, 'hushpage' ), $days ),
			__( 'Search engines treat a long-running 503 as a site that may be gone and can drop your pages. If the site is not launching soon, switch to "Coming soon" mode or finish the work and switch the page off.', 'hushpage' )
		);
	}

	/**
	 * Warns when a page cache is active that Hushpage can't clear, so visitors may keep seeing a stale page.
	 *
	 * @return array
	 */
	public static function test_cache() {
		if ( ! Hushpage_Settings::has_unknown_page_cache() ) {
			return self::result( 'hushpage_cache', 'good', __( 'Hushpage can clear your page cache', 'hushpage' ),
				__( 'When the maintenance page switches on or off, the page caches on this site are cleared automatically.', 'hushpage' ) );
		}
		return self::result( 'hushpage_cache', 'recommended', __( 'A page cache is active that Hushpage cannot clear', 'hushpage' ),
			__( 'This site uses a page cache that Hushpage does not recognise. After switching the maintenance page on or off, clear that cache yourself, or have your developer hook it into the hushpage_purge_caches action.', 'hushpage' ) );
	}
}
