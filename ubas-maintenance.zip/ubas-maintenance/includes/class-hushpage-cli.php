<?php
/**
 * WP-CLI commands: wp hushpage status|enable|disable|bypass-link
 *
 * @package Hushpage
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manage Hushpage from the command line.
 */
class Hushpage_CLI {

	/**
	 * Shows whether the maintenance page is on.
	 *
	 * ## EXAMPLES
	 *
	 *     wp hushpage status
	 */
	public function status() {
		$s = Hushpage_Settings::get();
		WP_CLI::line( sprintf( 'Enabled: %s', $s['enabled'] ? 'yes' : 'no' ) );
		WP_CLI::line( sprintf( 'Active now: %s', Hushpage_Settings::is_active() ? 'yes' : 'no' ) );
		WP_CLI::line( sprintf( 'Mode: %s', $s['mode'] ) );
		WP_CLI::line( sprintf( 'Switch on at: %s', $s['start_at'] ? $s['start_at'] : '-' ) );
		WP_CLI::line( sprintf( 'Switch off at: %s', $s['end_at'] ? $s['end_at'] : '-' ) );
		WP_CLI::line( sprintf( 'Applies to: %s', 'paths' === $s['scope'] ? 'only ' . str_replace( "\n", ', ', $s['paths'] ) : 'the whole site' ) );
	}

	/**
	 * Turns the maintenance page on.
	 *
	 * ## OPTIONS
	 *
	 * [--mode=<mode>]
	 * : maintenance or coming_soon.
	 *
	 * ## EXAMPLES
	 *
	 *     wp hushpage enable --mode=coming_soon
	 *
	 * @param array $args       Positional args.
	 * @param array $assoc_args Named args.
	 */
	public function enable( $args, $assoc_args ) {
		$this->set( true, isset( $assoc_args['mode'] ) ? $assoc_args['mode'] : null );
		WP_CLI::success( 'Maintenance page is on. Caches cleared.' );
	}

	/**
	 * Turns the maintenance page off.
	 *
	 * ## EXAMPLES
	 *
	 *     wp hushpage disable
	 */
	public function disable() {
		$this->set( false, null );
		Hushpage_Settings::clear_updates();
		WP_CLI::success( 'Maintenance page is off. Caches cleared.' );
	}

	/**
	 * Posts a live status update on the maintenance page, or clears them all.
	 *
	 * ## OPTIONS
	 *
	 * [<text>]
	 * : The update, e.g. "Backups done. Updating the shop now."
	 *
	 * [--clear]
	 * : Remove all updates instead.
	 *
	 * ## EXAMPLES
	 *
	 *     wp hushpage update "Database migrated, checking the shop"
	 *     wp hushpage update --clear
	 *
	 * @param array $args       Positional args.
	 * @param array $assoc_args Named args.
	 */
	public function update( $args, $assoc_args ) {
		if ( ! empty( $assoc_args['clear'] ) ) {
			Hushpage_Settings::clear_updates();
			WP_CLI::success( 'Status updates cleared.' );
			return;
		}
		if ( empty( $args[0] ) || ! Hushpage_Settings::add_update( $args[0] ) ) {
			WP_CLI::error( 'Give the update text, e.g. wp hushpage update "Backups done".' );
		}
		WP_CLI::success( 'Update posted.' );
	}

	/**
	 * Prints the secret bypass link.
	 *
	 * @subcommand bypass-link
	 */
	public function bypass_link() {
		$s = Hushpage_Settings::get();
		WP_CLI::line( add_query_arg( 'hushpage_bypass', rawurlencode( $s['bypass_token'] ), home_url( '/' ) ) );
	}

	/**
	 * Saves the switch (and optionally the mode), then clears caches.
	 *
	 * @param bool        $enabled On/off.
	 * @param string|null $mode    Mode.
	 */
	private function set( $enabled, $mode ) {
		$s                  = Hushpage_Settings::get();
		$s['enabled_since'] = $enabled ? ( $s['enabled'] && $s['enabled_since'] ? $s['enabled_since'] : time() ) : 0;
		$s['enabled']       = $enabled;
		if ( null !== $mode ) {
			if ( ! in_array( $mode, array( 'maintenance', 'coming_soon' ), true ) ) {
				WP_CLI::error( 'Mode must be maintenance or coming_soon.' );
			}
			$s['mode'] = $mode;
		}
		Hushpage_Settings::save_internal( $s );
		Hushpage_Settings::purge_caches( 'wp_cli' );
		Hushpage_Settings::schedule_window( $s );
	}
}
