<?php
/**
 * Removes everything the plugin stored. Nothing is left behind.
 *
 * @package Hushpage
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Deletes this plugin's options and scheduled event on the current site.
 */
function hushpage_uninstall_site() {
	foreach ( array( 'hushpage_settings', 'hushpage_cache_log', 'hushpage_state', 'hushpage_updates', 'hushpage_lock_hash' ) as $hushpage_option ) {
		delete_option( $hushpage_option );
	}
	delete_metadata( 'user', 0, 'hpl_unlock', '', true );
	wp_clear_scheduled_hook( 'hushpage_window_tick' );
	wp_clear_scheduled_hook( 'hushpage_cleanup' );
	// Contact form messages (private posts of type hushpage_message) and their meta.
	do {
		$hushpage_ids = get_posts(
			array(
				'post_type'   => 'hushpage_message',
				'post_status' => 'any',
				'numberposts' => 200,
				'fields'      => 'ids',
			)
		);
		foreach ( $hushpage_ids as $hushpage_id ) {
			wp_delete_post( $hushpage_id, true );
		}
	} while ( $hushpage_ids );
}

hushpage_uninstall_site();

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids', 'number' => 0 ) ) as $hushpage_site_id ) {
		switch_to_blog( $hushpage_site_id );
		hushpage_uninstall_site();
		restore_current_blog();
	}
}
